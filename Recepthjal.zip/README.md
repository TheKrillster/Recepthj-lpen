# Recepthjälpen

Android-app för recept, veckomeny och inköpslista.

- Läs in recept från en mapp med bilder, kamera, valda bilder eller webbsidor (dela en sida från webbläsaren till appen).
- Bilder tolkas av Claude (egen API-nyckel från platform.claude.com). Webbsidor med inbyggd receptdata läses gratis.
- Appen kommer ihåg vilka bilder som redan lästs in. Recept med samma namn hoppas över.
- Veckomeny med förslag från Claude utifrån dina recept och önskemål.
- Inköpslista som slår ihop ingredienser, grupperar efter avdelning och kan delas.
- Säkerhetskopia till/från fil.

Bygg: ladda upp projektet till GitHub. GitHub Actions bygger APK:n och lägger den under Releases.

Kommer senare: priser och erbjudanden från ICA och Willys.
