package se.krillster.recepthjalpen.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Enkel databas: allt sparas i en JSON-fil i appens privata lagring.
 * Varje ändring skrivs direkt till disk.
 */
class Repository(private val file: File) {

    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        coerceInputValues = true
    }

    /** Körs efter varje ändring, t.ex. för att hålla inköpslistan i takt med veckomenyn. */
    var normalize: (AppData) -> AppData = { it }

    private val _data = MutableStateFlow(load())
    val data: StateFlow<AppData> = _data

    private val saveScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    private fun load(): AppData =
        if (file.exists()) {
            runCatching { json.decodeFromString(AppData.serializer(), file.readText()) }
                .getOrElse {
                    // Spara undan trasig fil hellre än att skriva över den
                    file.copyTo(File(file.path + ".trasig"), overwrite = true)
                    AppData()
                }
        } else AppData()

    fun update(transform: (AppData) -> AppData) {
        _data.update { normalize(transform(it)) }
        saveScope.launch {
            mutex.withLock {
                val tmp = File(file.path + ".tmp")
                tmp.writeText(json.encodeToString(AppData.serializer(), _data.value))
                if (!tmp.renameTo(file)) {
                    file.writeText(tmp.readText())
                    tmp.delete()
                }
            }
        }
    }

    fun exportJson(): String = json.encodeToString(AppData.serializer(), _data.value.copy(
        settings = _data.value.settings.copy(apiKey = "")
    ))

    /** Slår ihop en säkerhetskopia med det som finns. Returnerar antal nya recept. */
    fun importJson(text: String): Int {
        val backup = json.decodeFromString(AppData.serializer(), text)
        var added = 0
        update { cur ->
            val ids = cur.recipes.map { it.id }.toSet()
            val titles = cur.recipes.map { it.title.lowercase().trim() }.toSet()
            val newOnes = backup.recipes.filter { it.id !in ids && it.title.lowercase().trim() !in titles }
            added = newOnes.size
            cur.copy(
                recipes = cur.recipes + newOnes,
                menu = backup.menu + cur.menu,
                importedUris = cur.importedUris + backup.importedUris,
            )
        }
        return added
    }
}
