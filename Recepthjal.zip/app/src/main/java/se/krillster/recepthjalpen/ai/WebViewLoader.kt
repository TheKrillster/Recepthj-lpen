package se.krillster.recepthjalpen.ai

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

/**
 * Öppnar en sida i en osynlig WebView (samma motor som Chrome) och plockar ut
 * receptdata (ld+json) och sidans text. Används när en vanlig hämtning inte räcker,
 * t.ex. när sidan byggs upp med JavaScript eller spärrar enkla anrop.
 */
object WebViewLoader {

    data class Page(val ldJson: List<String>, val text: String)

    private const val JS = """
        (function(){
          var s=[].map.call(document.querySelectorAll('script[type="application/ld+json"]'),function(e){return e.textContent;});
          var nd=document.getElementById('__NEXT_DATA__');
          return JSON.stringify({ld:s, next: nd ? nd.textContent : '', text: document.body ? document.body.innerText : ''});
        })()
    """

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun load(context: Context, url: String): Page? = withContext(Dispatchers.Main) {
        var webView: WebView? = null
        val result = withTimeoutOrNull(25_000) {
            suspendCancellableCoroutine { cont ->
                val handler = Handler(Looper.getMainLooper())
                val wv = WebView(context.applicationContext)
                webView = wv
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                var attempts = 0
                var started = false
                var best: Page? = null

                fun finish(p: Page?) {
                    if (cont.isActive) cont.resume(p)
                }

                fun poll() {
                    if (!cont.isActive) return
                    wv.evaluateJavascript(JS) { raw ->
                        val page = runCatching {
                            val json = JSONObject(JSONTokener(raw).nextValue() as String)
                            val ld = json.optJSONArray("ld") ?: JSONArray()
                            val blocks = (0 until ld.length()).map { ld.optString(it) }.toMutableList()
                            val next = json.optString("next")
                            if (next.isNotBlank()) blocks += next
                            Page(blocks, json.optString("text"))
                        }.getOrNull()
                        if (page != null) best = page
                        val hasRecipe = page?.ldJson?.any { it.contains("Recipe") } == true
                        attempts++
                        if (hasRecipe || attempts >= 12) finish(best)
                        else handler.postDelayed({ poll() }, 1000)
                    }
                }

                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, u: String?) {
                        if (!started) {
                            started = true
                            handler.postDelayed({ poll() }, 800)
                        }
                    }
                }
                wv.loadUrl(url)
            }
        }
        webView?.let { it.stopLoading(); it.destroy() }
        result
    }

    private const val SCROLL_JS = """
        (function(){
          window.scrollTo(0, document.body ? document.body.scrollHeight : 0);
          var n=0;
          [].forEach.call(document.querySelectorAll('button, a'), function(b){
            var t=(b.innerText||'').trim().toLowerCase();
            if (/^(visa fler|ladda fler|visa alla erbjudanden|visa mer|fler erbjudanden)/.test(t)) { try { b.click(); n++; } catch(e){} }
          });
          return (document.body ? document.body.innerText.length : 0);
        })()
    """

    /**
     * Öppnar en sida, scrollar och klickar "Visa fler" några gånger så att allt laddas,
     * och returnerar sidans synliga text. Används för butikernas erbjudandesidor.
     */
    @SuppressLint("SetJavaScriptEnabled")
    suspend fun loadText(context: Context, url: String, rounds: Int = 10): String? = withContext(Dispatchers.Main) {
        var webView: WebView? = null
        val result = withTimeoutOrNull(60_000) {
            suspendCancellableCoroutine { cont ->
                val handler = Handler(Looper.getMainLooper())
                val wv = WebView(context.applicationContext)
                webView = wv
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                // Liten "skärm" räcker, men sidan ska tro att det är en mobil
                wv.layout(0, 0, 1080, 2400)
                var started = false
                var round = 0
                var lastLen = -1
                var stable = 0

                fun finish() {
                    wv.evaluateJavascript("(function(){return document.body ? document.body.innerText : '';})()") { raw ->
                        val text = runCatching { JSONTokener(raw).nextValue() as String }.getOrNull()
                        if (cont.isActive) cont.resume(text)
                    }
                }

                fun step() {
                    if (!cont.isActive) return
                    wv.evaluateJavascript(SCROLL_JS) { raw ->
                        val len = raw?.toIntOrNull() ?: 0
                        if (len == lastLen) stable++ else stable = 0
                        lastLen = len
                        round++
                        if (round >= rounds || (stable >= 3 && len > 500)) finish()
                        else handler.postDelayed({ step() }, 1500)
                    }
                }

                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, u: String?) {
                        if (!started) {
                            started = true
                            handler.postDelayed({ step() }, 2500)
                        }
                    }
                }
                wv.loadUrl(url)
            }
        }
        webView?.let { it.stopLoading(); it.destroy() }
        result
    }
}
