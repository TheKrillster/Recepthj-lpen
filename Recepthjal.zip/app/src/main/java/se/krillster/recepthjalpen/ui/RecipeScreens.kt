package se.krillster.recepthjalpen.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import se.krillster.recepthjalpen.data.IngredientText
import se.krillster.recepthjalpen.data.Recipe
import java.io.File
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

private val sv = Locale("sv", "SE")

/** Bildväljare (filhanteraren) som öppnas i en given mapp. */
class OpenImagesAt : ActivityResultContracts.OpenMultipleDocuments() {
    var initial: Uri? = null
    override fun createIntent(context: android.content.Context, input: Array<String>): Intent =
        super.createIntent(context, input).apply {
            initial?.let { putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, it) }
        }
}

@Composable
fun RecipeImage(path: String?, modifier: Modifier) {
    if (path == null) return
    AsyncImage(
        model = if (path.startsWith("http")) path else File(path),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier
    )
}

// ============================ Receptlistan ============================

@Composable
fun RecipesScreen(vm: AppViewModel, modifier: Modifier, onOpen: (String) -> Unit, onNew: () -> Unit) {
    val data by vm.data.collectAsStateWithLifecycle()
    val imp by vm.importState.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var onlyFav by rememberSaveable { mutableStateOf(false) }
    var tagFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    val tags = remember(data.recipes) {
        data.recipes.flatMap { it.tags }.groupingBy { it }.eachCount().entries
            .sortedByDescending { it.value }.take(15).map { it.key }
    }
    val q = query.trim().lowercase(sv)
    val list = data.recipes
        .filter { !onlyFav || it.favorite }
        .filter { tagFilter == null || tagFilter in it.tags }
        .filter { r ->
            q.isEmpty() || r.title.lowercase(sv).contains(q) ||
                r.tags.any { it.contains(q) } || r.ingredients.any { it.name.lowercase(sv).contains(q) }
        }
        .sortedWith(compareByDescending<Recipe> { it.favorite }.thenBy { it.title.lowercase(sv) })

    val style = data.settings.listStyle
    var styleMenu by remember { mutableStateOf(false) }
    val full: (androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope.() -> androidx.compose.foundation.lazy.grid.GridItemSpan) =
        { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }

    Box(modifier.fillMaxSize()) {
        androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
            columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(if (style == "grid") 2 else 1),
            contentPadding = PaddingValues(bottom = 96.dp),
        ) {
            item(span = full) {
              Column {
                Row(Modifier.padding(start = 16.dp, top = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Recepthjälpen", style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f))
                    Box {
                        TextButton(onClick = { styleMenu = true }) {
                            Text(when (style) { "grid" -> "Bilder ▾"; "compact" -> "Kompakt ▾"; else -> "Lista ▾" })
                        }
                        androidx.compose.material3.DropdownMenu(expanded = styleMenu, onDismissRequest = { styleMenu = false }) {
                            listOf("list" to "Lista med små bilder", "grid" to "Stora bilder", "compact" to "Kompakt, bara namn").forEach { (id, label) ->
                                androidx.compose.material3.DropdownMenuItem(
                                    text = { Text(label, fontWeight = if (style == id) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = { vm.updateSettings { it.copy(listStyle = id) }; styleMenu = false }
                                )
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Sök recept eller ingrediens") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, "Rensa") } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp)
                )
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = onlyFav, onClick = { onlyFav = !onlyFav }, label = { Text("♥ Favoriter") }) }
                    items(tags) { t ->
                        FilterChip(selected = tagFilter == t, onClick = { tagFilter = if (tagFilter == t) null else t }, label = { Text(t) })
                    }
                }
              }
            }
            if (imp.running || imp.total > 0) item(span = full) { ImportBanner(vm, imp) }
            busy?.let { b ->
                item(span = full) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp)); Text(b)
                    }
                }
            }
            if (data.recipes.isEmpty() && !imp.running) {
                item(span = full) {
                    Column(Modifier.padding(24.dp)) {
                        Text("Inga recept ännu", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("Tryck på \"Lägg till\" för att läsa in din mapp med receptbilder, fotografera ett recept, välja bilder eller klistra in en webbadress.\n\nDu kan också dela en receptsida från webbläsaren direkt till Recepthjälpen.\n\nFör att tolka bilder behöver du en Claude API-nyckel under Inställningar.")
                    }
                }
            }
            items(list.size, key = { list[it].id }) { i ->
                val r = list[i]
                when (style) {
                    "grid" -> RecipeCard(r, onClick = { onOpen(r.id) })
                    "compact" -> CompactRow(r, onClick = { onOpen(r.id) })
                    else -> RecipeRow(r, onClick = { onOpen(r.id) })
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("Lägg till") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }
    if (showAdd) AddRecipeDialog(vm, onDismiss = { showAdd = false }, onNew = { showAdd = false; onNew() }, onOpen = onOpen)
}

@Composable
private fun RecipeRow(r: Recipe, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(10.dp))) {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                Text(r.title.take(1).uppercase(), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            }
            RecipeImage(r.imagePath, Modifier.fillMaxSize())
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val meta = listOfNotNull(
                r.timeMinutes?.let { "$it min" },
                "${r.servings} port",
                r.tags.take(3).joinToString(" · ").ifEmpty { null }
            ).joinToString("  ·  ")
            Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (r.favorite) Icon(Icons.Filled.Favorite, "Favorit", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ImportBanner(vm: AppViewModel, imp: ImportState) {
    Card(Modifier.fillMaxWidth().padding(16.dp, 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp)) {
            if (imp.running) {
                Text("Läser in bild ${imp.done + 1} av ${imp.total}", fontWeight = FontWeight.SemiBold)
                Text(imp.current, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { if (imp.total == 0) 0f else imp.done.toFloat() / imp.total }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("${imp.found} recept hittade hittills. Ha appen öppen tills den är klar.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.cancelImport() }) { Text("Avbryt") }
            } else {
                Text("Inläsningen är klar: ${imp.found} nya recept" + if (imp.skipped > 0) ", ${imp.skipped} fanns redan." else ".", fontWeight = FontWeight.SemiBold)
                imp.errors.take(5).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                if (imp.errors.size > 5) Text("…och ${imp.errors.size - 5} till", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.dismissImportSummary() }) { Text("OK") }
            }
        }
    }
}

@Composable
private fun AddRecipeDialog(vm: AppViewModel, onDismiss: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    val data by vm.data.collectAsStateWithLifecycle()
    var url by remember { mutableStateOf("") }
    var cameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            vm.importFolder(uri)
            onDismiss()
        }
    }
    val imagesContract = remember { OpenImagesAt() }
    val imagePicker = rememberLauncherForActivityResult(imagesContract) { uris ->
        if (uris.isNotEmpty()) { vm.rememberImageLocation(uris.first()); vm.importPickedImages(uris); onDismiss() }
    }
    val pagesContract = remember { OpenImagesAt() }
    val pagesPicker = rememberLauncherForActivityResult(pagesContract) { uris ->
        if (uris.isNotEmpty()) { vm.rememberImageLocation(uris.first()); vm.importOneRecipeFromImages(uris); onDismiss() }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) { vm.importPickedImages(listOf(u)); onDismiss() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lägg till recept") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (data.settings.folderUri != null) {
                    FilledTonalButton(onClick = { vm.rescanFolder(); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Läs in nya bilder från mappen")
                    }
                }
                OutlinedButton(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (data.settings.folderUri == null) "Läs in en mapp med bilder" else "Välj en annan mapp")
                }
                OutlinedButton(onClick = {
                    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
                    val f = File(dir, "foto-${UUID.randomUUID()}.jpg")
                    val u = FileProvider.getUriForFile(context, context.packageName + ".files", f)
                    cameraUri = u
                    camera.launch(u)
                }, modifier = Modifier.fillMaxWidth()) { Text("Fotografera ett recept") }
                OutlinedButton(onClick = {
                    imagesContract.initial = vm.initialImageLocation()
                    imagePicker.launch(arrayOf("image/*"))
                }, modifier = Modifier.fillMaxWidth()) { Text("Välj bilder (ett recept per bild)") }
                OutlinedButton(onClick = {
                    pagesContract.initial = vm.initialImageLocation()
                    pagesPicker.launch(arrayOf("image/*"))
                }, modifier = Modifier.fillMaxWidth()) { Text("Ett recept på flera bilder") }
                OutlinedButton(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Skriv in själv") }
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Webbadress till recept") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                FilledTonalButton(enabled = url.isNotBlank(), onClick = {
                    vm.importUrl(url) { id -> if (id != null) onOpen(id) }
                    onDismiss()
                }, modifier = Modifier.fillMaxWidth()) { Text("Hämta från webben") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Stäng") } }
    )
}

// ============================ Receptvy ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeDetailScreen(
    vm: AppViewModel,
    recipeId: String,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
) {
    val data by vm.data.collectAsStateWithLifecycle()
    val r = data.recipes.firstOrNull { it.id == recipeId }
    if (r == null) { androidx.compose.runtime.LaunchedEffect(Unit) { onBack() }; return }
    var servings by remember(r.id) { mutableIntStateOf(r.servings) }
    var confirmDelete by remember { mutableStateOf(false) }
    var pickDay by remember { mutableStateOf(false) }
    var pickMerge by remember { mutableStateOf(false) }
    val factor = servings.toDouble() / r.servings.coerceAtLeast(1)
    val context = LocalContext.current
    val offers = vm.currentOffers()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(r.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Tillbaka") } },
                actions = {
                    IconButton(onClick = { vm.toggleFavorite(r.id) }) {
                        Icon(if (r.favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorit")
                    }
                    IconButton(onClick = { onEdit(r.id) }) { Icon(Icons.Filled.Edit, "Redigera") }
                    IconButton(onClick = { pickMerge = true }) { Icon(Icons.Filled.Add, "Slå ihop med annat recept") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Ta bort") }
                }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 32.dp)) {
            item { RecipeImages(vm, r) }
            item {
                Column(Modifier.padding(16.dp)) {
                    Text(r.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    val meta = listOfNotNull(r.timeMinutes?.let { "⏱ $it min" }, r.tags.joinToString(" · ").ifEmpty { null }).joinToString("   ")
                    if (meta.isNotEmpty()) Text(meta, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Portioner", modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(onClick = { if (servings > 1) servings-- }) { Text("−") }
                        Text("$servings", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleLarge)
                        OutlinedButton(onClick = { servings++ }) { Text("+") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                        listOf(0.5 to "½×", 1.0 to "1×", 2.0 to "2×", 3.0 to "3×", 4.0 to "4×").forEach { (f, label) ->
                            val target = (r.servings * f).toInt().coerceAtLeast(1)
                            FilterChip(selected = servings == target, onClick = { servings = target }, label = { Text(label) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = { vm.addRecipeToShopping(r, servings) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.ShoppingCart, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Handla")
                        }
                        FilledTonalButton(onClick = { pickDay = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.DateRange, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Veckomeny")
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Ingredienser", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
            items(r.ingredients) { i ->
                val amount = IngredientText.formatAmount(i.amount?.times(factor))
                Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(listOf(amount, i.unit).filter { it.isNotBlank() }.joinToString(" "),
                        Modifier.width(90.dp), fontWeight = FontWeight.SemiBold)
                    Column {
                        Text(i.name + if (i.note.isNotBlank()) ", ${i.note}" else "")
                        se.krillster.recepthjalpen.data.OfferMatch.find(i.name, offers).firstOrNull()?.let { o ->
                            Text("🏷 ${o.storeName}: ${o.price}", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
            item {
                Text("Gör så här", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(16.dp, 20.dp, 16.dp, 8.dp))
            }
            itemsIndexed(r.steps) { idx, s ->
                Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text("${idx + 1}.", Modifier.width(28.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(s)
                }
            }
            if (r.notes.isNotBlank()) item {
                Text("Anteckningar", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
                Text(r.notes, Modifier.padding(horizontal = 16.dp))
            }
            if (r.source.isNotBlank()) item {
                val isUrl = r.source.startsWith("http")
                Text("Källa: ${r.source}", style = MaterialTheme.typography.bodySmall,
                    color = if (isUrl) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp).then(
                        if (isUrl) Modifier.clickable {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.source))) }
                        } else Modifier
                    ))
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Ta bort receptet?") },
        text = { Text("\"${r.title}\" tas bort permanent.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteRecipe(r.id); onBack() }) { Text("Ta bort") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Avbryt") } }
    )

    if (pickMerge) {
        var q by remember { mutableStateOf("") }
        val others = data.recipes.filter { it.id != r.id }
            .filter { q.isBlank() || it.title.contains(q, ignoreCase = true) }
            .sortedByDescending { it.created }
        AlertDialog(
            onDismissRequest = { pickMerge = false },
            title = { Text("Slå ihop med…") },
            text = {
                Column {
                    Text("Välj fortsättningen på \"${r.title}\". Ingredienser och steg läggs till sist, och det andra receptet tas bort.",
                        style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(q, { q = it }, placeholder = { Text("Sök") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        items(others, key = { it.id }) { o ->
                            Column(Modifier.fillMaxWidth().clickable { vm.mergeRecipes(r.id, o.id); pickMerge = false }
                                .padding(vertical = 10.dp)) {
                                Text(o.title, fontWeight = FontWeight.SemiBold)
                                Text("${o.ingredients.size} ingredienser · ${o.steps.size} steg" +
                                    if ("ofullständig" in o.tags) " · ofullständig" else "",
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickMerge = false }) { Text("Avbryt") } }
        )
    }

    if (pickDay) {
        val start = LocalDate.now()
        AlertDialog(
            onDismissRequest = { pickDay = false },
            title = { Text("Vilken dag?") },
            text = {
                LazyColumn {
                    items((0..13).map { start.plusDays(it.toLong()) }) { d ->
                        val current = data.menu[d.toString()]?.recipeId?.let { id -> data.recipes.firstOrNull { it.id == id }?.title }
                        Column(Modifier.fillMaxWidth().clickable {
                            vm.setMenu(d, r.id, servings); pickDay = false
                            vm.say("${r.title} lades in ${dayLabel(d)}.")
                        }.padding(vertical = 10.dp)) {
                            Text(dayLabel(d), fontWeight = FontWeight.SemiBold)
                            if (current != null) Text("Ersätter: $current", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickDay = false }) { Text("Avbryt") } }
        )
    }
}

fun dayLabel(d: LocalDate): String {
    val name = d.dayOfWeek.getDisplayName(TextStyle.FULL, sv).replaceFirstChar { it.uppercase() }
    return "$name ${d.dayOfMonth} ${d.month.getDisplayName(TextStyle.SHORT, sv).trimEnd('.')}"
}

// ============================ Redigera ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeEditScreen(vm: AppViewModel, recipeId: String?, onDone: (String?) -> Unit) {
    val data by vm.data.collectAsStateWithLifecycle()
    val original = remember(recipeId) {
        data.recipes.firstOrNull { it.id == recipeId }
            ?: Recipe(id = UUID.randomUUID().toString(), title = "", servings = data.settings.defaultServings)
    }
    var title by rememberSaveable { mutableStateOf(original.title) }
    var servings by rememberSaveable { mutableStateOf(original.servings.toString()) }
    var time by rememberSaveable { mutableStateOf(original.timeMinutes?.toString() ?: "") }
    var tags by rememberSaveable { mutableStateOf(original.tags.joinToString(", ")) }
    var ingredients by rememberSaveable { mutableStateOf(original.ingredients.joinToString("\n") { IngredientText.toLine(it) }) }
    var steps by rememberSaveable { mutableStateOf(original.steps.joinToString("\n\n")) }
    var notes by rememberSaveable { mutableStateOf(original.notes) }

    fun save() {
        val oldByLine = original.ingredients.associateBy { IngredientText.toLine(it) }
        val r = original.copy(
            title = title.trim().ifEmpty { "Namnlöst recept" },
            servings = servings.toIntOrNull()?.coerceAtLeast(1) ?: 4,
            timeMinutes = time.toIntOrNull(),
            tags = tags.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() },
            ingredients = ingredients.lines().map { it.trim() }.filter { it.isNotEmpty() }
                .map { line -> oldByLine[line] ?: IngredientText.parse(line) },
            steps = steps.split(Regex("\n\\s*\n")).map { it.replace('\n', ' ').trim() }.filter { it.isNotEmpty() },
            notes = notes.trim(),
        )
        vm.saveRecipe(r)
        onDone(r.id)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (recipeId == null) "Nytt recept" else "Redigera") },
            navigationIcon = { IconButton(onClick = { onDone(recipeId) }) { Icon(Icons.Filled.Close, "Avbryt") } },
            actions = { TextButton(onClick = { save() }) { Text("Spara") } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(title, { title = it }, label = { Text("Namn") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(servings, { servings = it.filter(Char::isDigit) }, label = { Text("Portioner") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(time, { time = it.filter(Char::isDigit) }, label = { Text("Tid (min)") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            OutlinedTextField(tags, { tags = it }, label = { Text("Taggar (komma emellan)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(ingredients, { ingredients = it }, label = { Text("Ingredienser, en per rad (t.ex. 2 dl grädde)") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp))
            OutlinedTextField(steps, { steps = it }, label = { Text("Gör så här (tom rad mellan stegen)") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp))
            OutlinedTextField(notes, { notes = it }, label = { Text("Anteckningar") }, modifier = Modifier.fillMaxWidth())
        }
    }
}


// ============================ Listvarianter ============================

@Composable
private fun RecipeCard(r: Recipe, onClick: () -> Unit) {
    Card(Modifier.padding(6.dp).fillMaxWidth().clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
            Text(r.title.take(1).uppercase(), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary)
            RecipeImage(r.imagePath, Modifier.fillMaxSize())
            if (r.favorite) Icon(Icons.Filled.Favorite, "Favorit", tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp))
        }
        Column(Modifier.padding(8.dp)) {
            Text(r.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(listOfNotNull(r.timeMinutes?.let { "$it min" }, "${r.servings} port").joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CompactRow(r: Recipe, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(r.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        r.timeMinutes?.let { Text("$it min", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (r.favorite) Icon(Icons.Filled.Favorite, "Favorit", tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(start = 8.dp).size(16.dp))
    }
    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
}

// ============================ Bilder på receptet ============================

@Composable
private fun RecipeImages(vm: AppViewModel, r: Recipe) {
    val context = LocalContext.current
    val all = listOfNotNull(r.imagePath) + r.images
    var viewing by remember { mutableStateOf<String?>(null) }
    var askAdd by remember { mutableStateOf(false) }
    var cameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val pickContract = remember { OpenImagesAt() }
    val picker = rememberLauncherForActivityResult(pickContract) { uris ->
        if (uris.isNotEmpty()) { vm.rememberImageLocation(uris.first()); vm.addRecipeImages(r.id, uris) }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) vm.addRecipeImages(r.id, listOf(u))
    }

    Column {
        if (r.imagePath != null) {
            RecipeImage(r.imagePath, Modifier.fillMaxWidth().height(230.dp).clickable { viewing = r.imagePath })
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(all.drop(1)) { p ->
                RecipeImage(p, Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)).clickable { viewing = p })
            }
            item {
                OutlinedButton(onClick = { askAdd = true }, modifier = Modifier.height(72.dp)) {
                    Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp))
                    Text(if (all.isEmpty()) "Lägg till bild" else "Bild")
                }
            }
        }
    }

    if (askAdd) AlertDialog(
        onDismissRequest = { askAdd = false },
        title = { Text("Lägg till bild") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    askAdd = false
                    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
                    val u = FileProvider.getUriForFile(context, context.packageName + ".files", File(dir, "foto-${UUID.randomUUID()}.jpg"))
                    cameraUri = u
                    camera.launch(u)
                }, modifier = Modifier.fillMaxWidth()) { Text("Ta ett foto") }
                OutlinedButton(onClick = {
                    askAdd = false
                    pickContract.initial = vm.initialImageLocation()
                    picker.launch(arrayOf("image/*"))
                }, modifier = Modifier.fillMaxWidth()) { Text("Välj från telefonen") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { askAdd = false }) { Text("Avbryt") } }
    )

    viewing?.let { p ->
        ImageViewer(
            path = p,
            isMain = p == r.imagePath,
            onClose = { viewing = null },
            onMakeMain = { vm.makeMainImage(r.id, p); viewing = null },
            onDelete = { vm.removeRecipeImage(r.id, p); viewing = null },
        )
    }
}

@Composable
private fun ImageViewer(path: String, isMain: Boolean, onClose: () -> Unit, onMakeMain: () -> Unit, onDelete: () -> Unit) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var confirmDelete by remember { mutableStateOf(false) }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
            AsyncImage(
                model = if (path.startsWith("http")) path else File(path),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = if (scale == 1f) androidx.compose.ui.geometry.Offset.Zero else offset + pan
                        }
                    }
                    .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
            )
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(androidx.compose.ui.graphics.Color(0x99000000)).padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly) {
                val white = androidx.compose.ui.graphics.Color.White
                TextButton(onClick = onClose) { Text("Stäng", color = white) }
                if (!isMain) TextButton(onClick = onMakeMain) { Text("Gör till huvudbild", color = white) }
                TextButton(onClick = { confirmDelete = true }) { Text("Ta bort", color = white) }
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Ta bort bilden?") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Ta bort") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Avbryt") } }
    )
}
