package se.krillster.recepthjalpen.ai

import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import se.krillster.recepthjalpen.data.IngredientText
import se.krillster.recepthjalpen.data.Recipe
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Läser recept från webbsidor. De flesta receptsajter (ICA, Arla, Coop, Köket m.fl.) har
 * inbyggd receptdata (schema.org/Recipe) som kan läsas gratis utan Claude.
 */
object WebImporter {

    suspend fun fetch(url: String): String = withContext(Dispatchers.IO) {
        var current = url
        repeat(5) {
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 10_000
                readTimeout = 15_000
                setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36")
                setRequestProperty("Accept-Language", "sv-SE,sv;q=0.9,en;q=0.8")
            }
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    current = URL(URL(current), conn.getHeaderField("Location")).toString()
                    return@repeat
                }
                if (code !in 200..299) throw ClaudeException("Sidan svarade med fel $code.")
                return@withContext conn.inputStream.bufferedReader().use { it.readText() }
            } finally {
                conn.disconnect()
            }
        }
        throw ClaudeException("För många omdirigeringar.")
    }

    fun findUrl(text: String): String? {
        val m = Regex("""(https?://|www\.)\S+""", RegexOption.IGNORE_CASE).find(text)?.value
            ?: Regex("""[a-z0-9.-]+\.(se|com|nu|net|org|dk|no)/\S*""", RegexOption.IGNORE_CASE).find(text)?.value
            ?: return null
        val url = m.trimEnd(')', '.', ',', '"', '\'')
        return if (url.startsWith("http", ignoreCase = true)) url else "https://$url"
    }

    fun ldBlocks(html: String): List<String> = Regex(
        """<script[^>]*type\s*=\s*["']application/ld\+json["'][^>]*>(.*?)</script>""",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
    ).findAll(html).map { it.groupValues[1].trim() }.toList()

    fun recipeFromStructuredData(html: String, url: String): Recipe? = recipeFromLdBlocks(ldBlocks(html), url)

    fun recipeFromLdBlocks(blocks: List<String>, url: String): Recipe? {
        for (block in blocks) {
            // Många sajter har radbrytningar inne i textsträngarna, vilket är ogiltig JSON
            val cleaned = block.replace(Regex("[\\u0000-\\u001F]"), " ")
            val value = runCatching { JSONTokener(cleaned).nextValue() }.getOrNull() ?: continue
            val obj = findRecipe(value, 0) ?: continue
            val r = runCatching { convert(obj, url) }.getOrNull() ?: continue
            if (r.ingredients.isNotEmpty() || r.steps.isNotEmpty()) return r
        }
        return null
    }

    private fun isRecipe(o: JSONObject): Boolean = when (val t = o.opt("@type")) {
        is String -> t.equals("Recipe", true)
        is JSONArray -> (0 until t.length()).any { t.optString(it).equals("Recipe", true) }
        else -> false
    }

    private fun findRecipe(v: Any?, depth: Int): JSONObject? {
        if (depth > 14) return null
        return when (v) {
            is JSONObject -> if (isRecipe(v)) v else {
                val keys = v.keys().asSequence().toList()
                keys.firstNotNullOfOrNull { findRecipe(v.opt(it), depth + 1) }
            }
            is JSONArray -> (0 until v.length()).firstNotNullOfOrNull { findRecipe(v.opt(it), depth + 1) }
            else -> null
        }
    }

    private fun clean(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()

    private fun strings(v: Any?): List<String> = when (v) {
        is String -> listOf(v)
        is JSONArray -> (0 until v.length()).flatMap { strings(v.opt(it)) }
        is JSONObject -> when {
            v.has("itemListElement") -> {
                val name = v.optString("name")
                val inner = strings(v.opt("itemListElement"))
                if (name.isNotBlank() && v.optString("@type").equals("HowToSection", true))
                    listOf("— $name —") + inner else inner
            }
            v.has("text") -> listOf(v.optString("text"))
            v.has("name") -> listOf(v.optString("name"))
            else -> emptyList()
        }
        else -> emptyList()
    }

    private fun minutes(iso: String?): Int? {
        if (iso.isNullOrBlank()) return null
        val m = Regex("""P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?""").find(iso) ?: return null
        val d = m.groupValues[1].toIntOrNull() ?: 0
        val h = m.groupValues[2].toIntOrNull() ?: 0
        val min = m.groupValues[3].toIntOrNull() ?: 0
        return (d * 1440 + h * 60 + min).takeIf { it > 0 }
    }

    private fun imageUrl(v: Any?): String? = when (v) {
        is String -> v
        is JSONArray -> if (v.length() > 0) imageUrl(v.opt(0)) else null
        is JSONObject -> v.optString("url").ifBlank { null }
        else -> null
    }

    private fun convert(o: JSONObject, url: String): Recipe {
        val ingredients = strings(o.opt("recipeIngredient") ?: o.opt("ingredients"))
            .map { clean(it) }.filter { it.isNotEmpty() }.map { IngredientText.parse(it) }
        val steps = strings(o.opt("recipeInstructions")).flatMap { clean(it).split(Regex("\n+")) }
            .map { it.trim() }.filter { it.isNotEmpty() }
        val yieldText = strings(o.opt("recipeYield")).firstOrNull()
            ?: o.opt("recipeYield")?.toString() ?: ""
        val servings = Regex("""\d+""").find(yieldText)?.value?.toIntOrNull() ?: 4
        val time = minutes(o.optString("totalTime"))
            ?: listOfNotNull(minutes(o.optString("prepTime")), minutes(o.optString("cookTime"))).sum().takeIf { it > 0 }
        val tags = (strings(o.opt("recipeCategory")) + strings(o.opt("keywords")).flatMap { it.split(',') })
            .map { clean(it).lowercase() }.filter { it.isNotEmpty() && it.length < 25 }.distinct().take(5)
        return Recipe(
            id = UUID.randomUUID().toString(),
            title = clean(o.optString("name")).ifEmpty { "Recept från webben" },
            servings = servings,
            timeMinutes = time,
            ingredients = ingredients,
            steps = steps,
            tags = tags,
            source = url,
            imagePath = imageUrl(o.opt("image")),
        )
    }

    /** Gör om HTML till ren text att skicka till Claude när sidan saknar receptdata. */
    fun htmlToText(html: String): String {
        val noScripts = html
            .replace(Regex("<(script|style|noscript|svg|nav|footer|header)[^>]*>.*?</\\1>",
                setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), " ")
        val text = Html.fromHtml(noScripts, Html.FROM_HTML_MODE_LEGACY).toString()
        return text.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n").take(40_000)
    }
}
