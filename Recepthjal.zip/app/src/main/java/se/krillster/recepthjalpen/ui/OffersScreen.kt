package se.krillster.recepthjalpen.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import se.krillster.recepthjalpen.data.Categories
import se.krillster.recepthjalpen.data.OfferMatch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ============================ Erbjudanden ============================

@Composable
fun OffersScreen(vm: AppViewModel, modifier: Modifier, onAddStore: () -> Unit) {
    val data by vm.data.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var storeFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var onlyMenu by rememberSaveable { mutableStateOf(false) }
    val sv = Locale("sv", "SE")
    val stale = vm.offersStale()

    // Ingredienser i veckans meny – för att kunna visa "passar din meny"
    val menuIngredients = remember(data) {
        val start = vm.weekOf(data)
        (0..6).mapNotNull { data.menu[start.plusDays(it.toLong()).toString()]?.recipeId }
            .mapNotNull { id -> data.recipes.firstOrNull { it.id == id } }
            .flatMap { it.ingredients.map { i -> i.name } }
    }
    val q = query.trim().lowercase(sv)
    val list = data.offers
        .filter { storeFilter == null || it.storeId == storeFilter }
        .filter { q.isEmpty() || it.name.lowercase(sv).contains(q) || it.brand.lowercase(sv).contains(q) || it.keywords.any { k -> k.contains(q) } }
        .filter { !onlyMenu || menuIngredients.any { n -> OfferMatch.matches(n, it) } }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Row(Modifier.padding(start = 16.dp, top = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Erbjudanden", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                    val info = if (data.offersFetched == 0L) "Inte hämtade ännu"
                    else "Hämtade " + SimpleDateFormat("EEEE d MMM HH:mm", sv).format(Date(data.offersFetched)) +
                        if (stale) " – gamla, hämta nya" else ""
                    Text(info, style = MaterialTheme.typography.bodySmall,
                        color = if (stale && data.offersFetched != 0L) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { vm.refreshOffers() }) { Icon(Icons.Filled.Refresh, "Hämta erbjudanden") }
            }
            if (data.stores.isEmpty()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Lägg till dina butiker, t.ex. Willys Ystad och ICA Kvantum Ystad, så hämtar appen veckans erbjudanden och använder dem när den föreslår middagar.")
                    Spacer(Modifier.height(8.dp))
                    FilledTonalButton(onClick = onAddStore) { Text("Lägg till butiker") }
                }
            } else {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Sök erbjudande") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, "Rensa") } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp)
                )
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = onlyMenu, onClick = { onlyMenu = !onlyMenu }, label = { Text("Passar veckomenyn") }) }
                    items(data.stores) { s ->
                        FilterChip(selected = storeFilter == s.id, onClick = { storeFilter = if (storeFilter == s.id) null else s.id },
                            label = { Text(s.name) })
                    }
                }
                if (data.offers.isEmpty()) Text("Tryck på pilen uppe till höger för att hämta veckans erbjudanden. Det tar en stund per butik.",
                    Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Categories.ALL.forEach { cat ->
            val inCat = list.filter { it.category == cat }
            if (inCat.isNotEmpty()) {
                item(key = "cat-$cat") {
                    Text(cat, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(16.dp, 14.dp, 16.dp, 2.dp))
                }
                items(inCat) { o ->
                    val inMenu = menuIngredients.any { n -> OfferMatch.matches(n, o) }
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(listOf(o.name, o.brand).filter { it.isNotBlank() }.joinToString(" · "),
                                fontWeight = if (inMenu) FontWeight.SemiBold else FontWeight.Normal)
                            Text(listOf(o.price, o.compare, o.condition, o.storeName).filter { it.isNotBlank() }.joinToString("  ·  "),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (inMenu) Text("Passar din veckomeny", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary)
                        }
                        IconButton(onClick = { vm.addOfferToShopping(o) }) { Icon(Icons.Filled.Add, "Lägg i inköpslistan") }
                    }
                }
            }
        }
    }
}

// ============================ Välj butik ============================

private val START_URLS = mapOf(
    "Willys" to "https://www.willys.se/erbjudanden/butik",
    "ICA" to "https://www.ica.se/erbjudanden/",
)

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreBrowserScreen(vm: AppViewModel, chain: String, onDone: () -> Unit) {
    var currentUrl by remember { mutableStateOf(START_URLS[chain] ?: "https://www.google.se") }
    var title by remember { mutableStateOf("") }
    var progress by remember { mutableIntStateOf(0) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var askName by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(
            title = {
                Column {
                    Text("Välj $chain-butik", maxLines = 1)
                    Text(currentUrl, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            },
            navigationIcon = {
                IconButton(onClick = { if (webView?.canGoBack() == true) webView?.goBack() else onDone() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Tillbaka")
                }
            },
            actions = {
                TextButton(onClick = {
                    name = "$chain " + title.substringBefore('|').substringBefore(" - ").trim().take(40)
                    askName = true
                }) { Text("Spara") }
            }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Card(Modifier.fillMaxWidth().padding(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Text(
                    "Välj din butik (t.ex. $chain Ystad) och gå till butikens erbjudanden, så att sidan visar just din butiks veckoerbjudanden. Tryck sedan Spara.",
                    Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall
                )
            }
            if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView, url: String?) {
                                currentUrl = url ?: currentUrl
                                title = view.title ?: ""
                            }
                            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                                currentUrl = url ?: currentUrl
                            }
                        }
                        webChromeClient = object : android.webkit.WebChromeClient() {
                            override fun onProgressChanged(view: WebView, newProgress: Int) { progress = newProgress }
                        }
                        loadUrl(currentUrl)
                        webView = this
                    }
                }
            )
        }
    }

    if (askName) AlertDialog(
        onDismissRequest = { askName = false },
        title = { Text("Spara butik") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Namn") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Text("Sidan som sparas:\n$currentUrl", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                android.webkit.CookieManager.getInstance().flush()
                vm.addStore(chain, name.ifBlank { chain }, currentUrl)
                vm.say("${name.ifBlank { chain }} sparades. Hämta erbjudanden under fliken Erbjudanden.")
                askName = false
                onDone()
            }) { Text("Spara") }
        },
        dismissButton = { TextButton(onClick = { askName = false }) { Text("Avbryt") } }
    )
}
