package se.krillster.recepthjalpen.data

import java.util.Locale
import kotlin.math.abs
import kotlin.math.round

/** Tolkning, formatering och sammanslagning av ingredienser. */
object IngredientText {

    private val units = setOf(
        "kg", "g", "hg", "l", "dl", "cl", "ml", "msk", "tsk", "krm", "st", "förp", "paket",
        "burk", "burkar", "påse", "påsar", "klyfta", "klyftor", "kruka", "krukor", "knippe",
        "skiva", "skivor", "nypa", "port", "liter", "gram", "kilo", "ask", "flaska", "tub"
    )
    private val unitAlias = mapOf("liter" to "l", "gram" to "g", "kilo" to "kg", "burkar" to "burk",
        "påsar" to "påse", "klyftor" to "klyfta", "krukor" to "kruka", "skivor" to "skiva", "paket" to "förp")

    private val fractionChars = mapOf('½' to 0.5, '¼' to 0.25, '¾' to 0.75, '⅓' to 1.0 / 3, '⅔' to 2.0 / 3)

    private val amountRegex = Regex(
        """^\s*(\d+\s*[½¼¾⅓⅔]|\d+(?:[.,]\d+)?\s*/\s*\d+|\d+(?:[.,]\d+)?|[½¼¾⅓⅔])(?:\s*[-–]\s*(?:\d+(?:[.,]\d+)?|[½¼¾⅓⅔]))?\s*(.*)$"""
    )

    private fun parseNumber(s: String): Double? {
        val t = s.replace(" ", "")
        fractionChars[t.lastOrNull() ?: return null]?.let { frac ->
            val whole = t.dropLast(1)
            return (whole.toDoubleOrNull() ?: 0.0) + frac
        }
        if ('/' in t) {
            val (a, b) = t.split('/')
            val bb = b.toDoubleOrNull() ?: return null
            return (a.replace(',', '.').toDoubleOrNull() ?: return null) / bb
        }
        return t.replace(',', '.').toDoubleOrNull()
    }

    /** "2 dl vispgrädde" -> Ingredient(name="vispgrädde", amount=2.0, unit="dl") */
    fun parse(line: String): Ingredient {
        val text = line.trim().trimStart('-', '•', '*').trim()
        var amount: Double? = null
        var rest = text
        amountRegex.find(text)?.let { m ->
            amount = parseNumber(m.groupValues[1])
            rest = m.groupValues[2]
        }
        var unit = ""
        val firstWord = rest.substringBefore(' ').trimEnd('.').lowercase(Locale("sv"))
        if (amount != null && firstWord in units) {
            unit = unitAlias[firstWord] ?: firstWord
            rest = rest.substringAfter(' ', "")
        }
        var name = rest.trim()
        var note = ""
        if (',' in name) {
            note = name.substringAfter(',').trim()
            name = name.substringBefore(',').trim()
        }
        if (name.isEmpty()) name = text
        return Ingredient(name = name, amount = amount, unit = unit, note = note, category = guessCategory(name))
    }

    fun toLine(i: Ingredient): String = buildString {
        val a = formatAmount(i.amount)
        if (a.isNotEmpty()) append(a).append(' ')
        if (i.unit.isNotEmpty()) append(i.unit).append(' ')
        append(i.name)
        if (i.note.isNotEmpty()) append(", ").append(i.note)
    }

    fun formatAmount(d: Double?): String {
        if (d == null || d <= 0.0) return ""
        val nice = mapOf(0.25 to "¼", 0.5 to "½", 0.75 to "¾", 1.0 / 3 to "⅓", 2.0 / 3 to "⅔")
        val whole = d.toLong()
        val frac = d - whole
        if (abs(frac) < 0.04) return whole.toString()
        nice.entries.firstOrNull { abs(it.key - frac) < 0.04 }?.let {
            return if (whole == 0L) it.value else "$whole ${it.value}"
        }
        val r = if (d < 10) round(d * 10) / 10 else round(d)
        return if (r == round(r)) r.toLong().toString() else r.toString().replace('.', ',')
    }

    /** Normaliserar till basenhet så att 3 dl + 200 ml kan läggas ihop. */
    private fun toBase(amount: Double?, unit: String): Pair<Double?, String> = when (unit.lowercase()) {
        "kg" -> amount?.times(1000) to "g"
        "hg" -> amount?.times(100) to "g"
        "g" -> amount to "g"
        "l" -> amount?.times(1000) to "ml"
        "dl" -> amount?.times(100) to "ml"
        "cl" -> amount?.times(10) to "ml"
        "ml" -> amount to "ml"
        else -> amount to unit.lowercase()
    }

    private fun fromBase(amount: Double?, unit: String): Pair<Double?, String> {
        if (amount == null) return null to unit
        return when (unit) {
            "g" -> if (amount >= 1000) amount / 1000 to "kg" else amount to "g"
            "ml" -> when {
                amount >= 1000 -> amount / 1000 to "l"
                amount >= 50 -> amount / 100 to "dl"
                else -> amount to "ml"
            }
            else -> amount to unit
        }
    }

    fun key(name: String, unit: String): String =
        name.lowercase(Locale("sv")).trim() + "|" + toBase(null, unit).second

    data class Need(val ingredient: Ingredient, val recipeTitle: String)

    /** Slår ihop ingredienser med samma namn och kompatibel enhet. */
    fun merge(needs: List<Need>): List<ShoppingItem> {
        data class Acc(var amount: Double?, val unit: String, val name: String, val category: String, val from: MutableSet<String>)
        val map = LinkedHashMap<String, Acc>()
        for (n in needs) {
            val (a, u) = toBase(n.ingredient.amount, n.ingredient.unit)
            val key = n.ingredient.name.lowercase(Locale("sv")).trim() + "|" + u
            val acc = map.getOrPut(key) { Acc(null, u, n.ingredient.name.trim(), n.ingredient.category, mutableSetOf()) }
            if (a != null) acc.amount = (acc.amount ?: 0.0) + a
            acc.from += n.recipeTitle
        }
        return map.values.map { acc ->
            val (a, u) = fromBase(acc.amount, acc.unit)
            ShoppingItem(
                id = java.util.UUID.randomUUID().toString(),
                name = acc.name, amount = a, unit = u, category = acc.category,
                fromRecipes = acc.from.toList()
            )
        }
    }

    private val keywords: List<Pair<String, List<String>>> = listOf(
        Categories.FROZEN to listOf("fryst", "frysta", "glass"),
        Categories.SPICES to listOf("salt", "peppar", "paprikapulver", "spiskummin", "kanel", "kardemumma", "curry",
            "oregano", "timjan", "basilika, torkad", "chili", "buljong", "fond", "soja", "sambal", "senap", "ketchup",
            "vinäger", "tabasco", "sriracha", "kryddor", "muskot", "ingefära, malen", "lagerblad", "vaniljsocker",
            "fiskås", "worcester", "majonnäs", "pesto", "sweet chili"),
        Categories.MEAT to listOf("kyckling", "fläsk", "nöt", "färs", "bacon", "korv", "skinka", "lax", "torsk",
            "räkor", "fisk", "kött", "entrecote", "biff", "lamm", "kalkon", "sej", "tonfisk", "chorizo", "salami",
            "pancetta", "kassler", "högrev", "fläskfilé", "falukorv"),
        Categories.DAIRY to listOf("mjölk", "grädde", "ost", "smör", "ägg", "yoghurt", "crème fraiche", "creme fraiche",
            "kvarg", "keso", "fil", "mozzarella", "parmesan", "fetaost", "halloumi", "mascarpone", "kesella",
            "matlagningsgrädde", "cheddar", "ricotta", "havredryck"),
        Categories.BREAD to listOf("bröd", "tortilla", "pitabröd", "hamburgerbröd", "baguette", "tunnbröd", "knäckebröd",
            "ströbröd", "panko", "lavash", "naan"),
        Categories.PRODUCE to listOf("lök", "vitlök", "tomat", "potatis", "morot", "morötter", "paprika", "gurka",
            "sallad", "spenat", "citron", "lime", "äpple", "banan", "avokado", "broccoli", "blomkål", "zucchini",
            "aubergine", "svamp", "champinjon", "purjolök", "selleri", "ingefära", "koriander", "persilja", "dill",
            "basilika", "gräslök", "rödlök", "salladslök", "kål", "bär", "jordgubb", "hallon", "blåbär", "apelsin",
            "päron", "sötpotatis", "rödbeta", "majs", "ärtor", "bönor, färska", "sparris", "fänkål", "rucola",
            "mynta", "chili, färsk", "squash", "pumpa", "palsternacka", "mango", "ananas", "druvor", "rotselleri"),
        Categories.PANTRY to listOf("mjöl", "socker", "ris", "pasta", "spaghetti", "makaroner", "nudlar", "olja",
            "krossade tomater", "tomatpuré", "bönor", "linser", "kikärtor", "kokosmjölk", "havregryn", "honung",
            "sirap", "bakpulver", "jäst", "bulgur", "couscous", "quinoa", "nötter", "mandel", "russin", "choklad",
            "kakao", "vin", "passerade tomater", "majsstärkelse", "maizena", "gnocchi", "lasagneplattor", "tacos",
            "tacosås", "kapris", "oliver", "sesamfrön", "jordnötter", "cashew", "flingsalt", "potatismjöl"),
    )

    fun guessCategory(name: String): String {
        val n = name.lowercase(Locale("sv"))
        for ((cat, words) in keywords) {
            if (words.any { n.contains(it) }) return cat
        }
        return Categories.OTHER
    }

    fun isStaple(name: String, staples: String): Boolean {
        val n = name.lowercase(Locale("sv")).trim()
        return staples.split(',', '\n').map { it.trim().lowercase(Locale("sv")) }
            .filter { it.isNotEmpty() }
            .any { n == it || n.startsWith("$it ") || n.endsWith(" $it") }
    }
}
