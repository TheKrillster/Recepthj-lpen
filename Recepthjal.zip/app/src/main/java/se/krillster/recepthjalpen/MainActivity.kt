package se.krillster.recepthjalpen

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.toArgb
import se.krillster.recepthjalpen.ui.OffersScreen
import se.krillster.recepthjalpen.ui.StoreBrowserScreen
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import se.krillster.recepthjalpen.ui.AppViewModel
import se.krillster.recepthjalpen.ui.MenuScreen
import se.krillster.recepthjalpen.ui.RecipeDetailScreen
import se.krillster.recepthjalpen.ui.RecipeEditScreen
import se.krillster.recepthjalpen.ui.RecipesScreen
import se.krillster.recepthjalpen.ui.SettingsScreen
import se.krillster.recepthjalpen.ui.ShoppingScreen

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleShare(intent)
        setContent {
            val data by vm.data.collectAsStateWithLifecycle()
            RecepthjalpenTheme(data.settings.theme) { App(vm) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleShare(intent: Intent?) {
        intent ?: return
        when (intent.action) {
            Intent.ACTION_SEND -> {
                if (intent.type?.startsWith("image/") == true) {
                    val uri: Uri? = if (Build.VERSION.SDK_INT >= 33)
                        intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                    else intent.getParcelableExtra(Intent.EXTRA_STREAM)
                    uri?.let { vm.importPickedImages(listOf(it)) }
                } else {
                    val text = listOfNotNull(
                        intent.getStringExtra(Intent.EXTRA_TEXT),
                        intent.getStringExtra(Intent.EXTRA_SUBJECT)
                    ).joinToString(" ")
                    vm.importUrl(text)
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val uris: List<Uri>? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                uris?.let { vm.importPickedImages(it) }
            }
        }
    }
}

private val Green = Color(0xFF2E5E3A)

@Composable
fun RecepthjalpenTheme(theme: String, content: @Composable () -> Unit) {
    val dark = when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF9FD4A8),
        onPrimary = Color(0xFF0B3818),
        primaryContainer = Color(0xFF24502F),
        onPrimaryContainer = Color(0xFFCFE8D2),
        secondary = Color(0xFFF2C46B),
        secondaryContainer = Color(0xFF5A4300),
        background = Color(0xFF151815),
        surface = Color(0xFF151815),
        surfaceVariant = Color(0xFF262B26),
        onSurfaceVariant = Color(0xFFC2C8C0),
    ) else lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFCFE8D2),
            onPrimaryContainer = Color(0xFF0E2614),
            secondary = Color(0xFFB8860B),
            secondaryContainer = Color(0xFFFFE8B5),
            background = Color(0xFFFFFBF6),
            surface = Color(0xFFFFFBF6),
            surfaceVariant = Color(0xFFF1ECE4),
        )
    val view = androidx.compose.ui.platform.LocalView.current
    if (!view.isInEditMode) {
        androidx.compose.runtime.SideEffect {
            val window = (view.context as android.app.Activity).window
            @Suppress("DEPRECATION")
            window.statusBarColor = (if (dark) Color(0xFF151815) else Green).toArgb()
            window.decorView.setBackgroundColor(scheme.background.toArgb())
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

enum class Tab(val label: String, val icon: ImageVector) {
    RECIPES("Recept", Icons.AutoMirrored.Filled.List),
    MENU("Veckomeny", Icons.Filled.DateRange),
    SHOPPING("Inköp", Icons.Filled.ShoppingCart),
    OFFERS("Erbjudanden", Icons.Filled.Star),
    SETTINGS("Inställningar", Icons.Filled.Settings),
}

@Composable
fun App(vm: AppViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.RECIPES) }
    var openRecipeId by rememberSaveable { mutableStateOf<String?>(null) }
    var editRecipeId by rememberSaveable { mutableStateOf<String?>(null) } // "new" = nytt recept
    var addStoreChain by rememberSaveable { mutableStateOf<String?>(null) }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        vm.messages.collect { msg ->
            snackbar.showSnackbar(msg, withDismissAction = true, duration = SnackbarDuration.Long)
        }
    }

    BackHandler(enabled = addStoreChain != null || editRecipeId != null || openRecipeId != null || tab != Tab.RECIPES) {
        when {
            addStoreChain != null -> addStoreChain = null
            editRecipeId != null -> editRecipeId = null
            openRecipeId != null -> openRecipeId = null
            else -> tab = Tab.RECIPES
        }
    }

    // Pågående arbete och viktiga besked visas i en ruta, oavsett vilken flik man är på
    val busy by vm.busy.collectAsStateWithLifecycle()
    val alert by vm.alert.collectAsStateWithLifecycle()
    busy?.let { text ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Vänta lite") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(16.dp))
                    Text(text)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { vm.cancelBusy() }) { Text("Avbryt") } }
        )
    }
    alert?.let { text ->
        AlertDialog(
            onDismissRequest = { vm.dismissAlert() },
            text = { Text(text, Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = { vm.dismissAlert() }) { Text("OK") } }
        )
    }

    when {
        addStoreChain != null -> StoreBrowserScreen(vm, addStoreChain!!, onDone = { addStoreChain = null })
        editRecipeId != null -> RecipeEditScreen(
            vm = vm,
            recipeId = editRecipeId!!.takeIf { it != "new" },
            onDone = { savedId ->
                editRecipeId = null
                if (savedId != null) openRecipeId = savedId
            }
        )
        openRecipeId != null -> RecipeDetailScreen(
            vm = vm,
            recipeId = openRecipeId!!,
            snackbar = snackbar,
            onBack = { openRecipeId = null },
            onEdit = { editRecipeId = it },
        )
        else -> Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(if (t == Tab.SETTINGS) "Mer" else t.label, maxLines = 1) }
                        )
                    }
                }
            }
        ) { pad ->
            val m = Modifier.padding(pad)
            when (tab) {
                Tab.RECIPES -> RecipesScreen(vm, m, onOpen = { openRecipeId = it }, onNew = { editRecipeId = "new" })
                Tab.MENU -> MenuScreen(vm, m, onOpen = { openRecipeId = it })
                Tab.SHOPPING -> ShoppingScreen(vm, m)
                Tab.OFFERS -> OffersScreen(vm, m, onAddStore = { tab = Tab.SETTINGS })
                Tab.SETTINGS -> SettingsScreen(vm, m, onAddStore = { addStoreChain = it })
            }
        }
    }
}
