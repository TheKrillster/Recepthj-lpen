package se.krillster.recepthjalpen.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.IsoFields
import java.util.Locale

@Composable
fun MenuScreen(vm: AppViewModel, modifier: Modifier, onOpen: (String) -> Unit) {
    val data by vm.data.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var weekOffset by rememberSaveable { mutableIntStateOf(0) }
    val weekStart = LocalDate.now().with(DayOfWeek.MONDAY).plusWeeks(weekOffset.toLong())
    val weekNo = weekStart.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR)
    var pickFor by remember { mutableStateOf<LocalDate?>(null) }
    var askReplace by remember { mutableStateOf(false) }

    val days = (0..6).map { weekStart.plusDays(it.toLong()) }
    val filled = days.count { data.menu[it.toString()]?.recipeId != null }

    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { weekOffset-- }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Förra veckan") }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Vecka $weekNo", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                    Text(when (weekOffset) { 0 -> "Denna vecka"; 1 -> "Nästa vecka"; -1 -> "Förra veckan"; else -> "${weekStart.dayOfMonth}/${weekStart.monthValue}" },
                        style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { weekOffset++ }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Nästa vecka") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                FilledTonalButton(
                    enabled = busy == null,
                    onClick = { if (filled == 7) askReplace = true else vm.suggestWeek(weekStart, replaceAll = false) },
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Filled.Star, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Föreslå") }
                val linked = vm.weekOf(data) == weekStart
                FilledTonalButton(enabled = !linked, onClick = {
                    vm.linkWeek(weekStart)
                    vm.say("Inköpslistan följer nu vecka $weekNo.")
                }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.ShoppingCart, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                    Text(if (linked) "På listan" else "Handla veckan")
                }
            }
            busy?.let {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp)); Text(it)
                }
            }
        }
        items(days) { d ->
            val entry = data.menu[d.toString()]
            val recipe = entry?.recipeId?.let { id -> data.recipes.firstOrNull { it.id == id } }
            val today = d == LocalDate.now()
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (today) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.fillMaxWidth().clickable { if (recipe != null) onOpen(recipe.id) else pickFor = d }
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (recipe?.imagePath != null) {
                        RecipeImage(recipe.imagePath, Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(dayLabel(d), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Text(recipe?.title ?: "Inget planerat", style = MaterialTheme.typography.titleMedium,
                            color = if (recipe == null) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (recipe != null && !entry?.note.isNullOrBlank())
                            Text(entry?.note ?: "", style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    TextButton(onClick = { pickFor = d }) { Text(if (recipe == null) "Välj" else "Byt") }
                }
            }
        }
        item {
            Text("Tryck på \"Föreslå\" så fyller Claude de tomma dagarna utifrån dina recept och önskemål (ställ in önskemål under Inställningar).",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp))
        }
    }

    pickFor?.let { day -> RecipePicker(vm, day, onDismiss = { pickFor = null }) }

    if (askReplace) AlertDialog(
        onDismissRequest = { askReplace = false },
        title = { Text("Veckan är redan full") },
        text = { Text("Vill du ersätta hela veckan med nya förslag?") },
        confirmButton = { TextButton(onClick = { askReplace = false; vm.suggestWeek(weekStart, replaceAll = true) }) { Text("Ersätt") } },
        dismissButton = { TextButton(onClick = { askReplace = false }) { Text("Avbryt") } }
    )
}

@Composable
private fun RecipePicker(vm: AppViewModel, day: LocalDate, onDismiss: () -> Unit) {
    val data by vm.data.collectAsStateWithLifecycle()
    val current = data.menu[day.toString()]
    var query by remember { mutableStateOf("") }
    var servings by remember { mutableIntStateOf(current?.servings ?: data.settings.defaultServings) }
    val sv = Locale("sv", "SE")
    val list = data.recipes.filter { query.isBlank() || it.title.lowercase(sv).contains(query.lowercase(sv)) }
        .sortedWith(compareByDescending<se.krillster.recepthjalpen.data.Recipe> { it.favorite }.thenBy { it.title.lowercase(sv) })

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dayLabel(day)) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Portioner", Modifier.weight(1f))
                    OutlinedButton(onClick = { if (servings > 1) servings-- }) { Text("−") }
                    Text("$servings", Modifier.padding(horizontal = 12.dp))
                    OutlinedButton(onClick = { servings++ }) { Text("+") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(query, { query = it }, placeholder = { Text("Sök") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, null) }, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(list, key = { it.id }) { r ->
                        Text(
                            (if (r.favorite) "♥ " else "") + r.title,
                            fontWeight = if (r.id == current?.recipeId) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().clickable { vm.setMenu(day, r.id, servings); onDismiss() }
                                .padding(vertical = 10.dp)
                        )
                    }
                    if (list.isEmpty()) item { Text("Inga recept hittades.", Modifier.padding(vertical = 10.dp)) }
                }
            }
        },
        confirmButton = {
            if (current?.recipeId != null) TextButton(onClick = {
                vm.setMenu(day, current.recipeId, servings, current.note); onDismiss()
            }) { Text("Spara portioner") }
        },
        dismissButton = {
            Row {
                if (current != null) TextButton(onClick = { vm.setMenu(day, null, 0); onDismiss() }) { Text("Töm dagen") }
                TextButton(onClick = onDismiss) { Text("Stäng") }
            }
        }
    )
}
