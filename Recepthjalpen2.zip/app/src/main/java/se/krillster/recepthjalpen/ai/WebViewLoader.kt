package se.krillster.recepthjalpen.ai

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

/**
 * Öppnar en sida i en osynlig WebView (samma motor som Chrome) och plockar ut
 * receptdata (ld+json) och sidans text. Används när en vanlig hämtning inte räcker,
 * t.ex. när sidan byggs upp med JavaScript eller spärrar enkla anrop.
 */
object WebViewLoader {

    data class Page(val ldJson: List<String>, val text: String)

    private const val JS = """
        (function(){
          var s=[].map.call(document.querySelectorAll('script[type="application/ld+json"]'),function(e){return e.textContent;});
          var nd=document.getElementById('__NEXT_DATA__');
          return JSON.stringify({ld:s, next: nd ? nd.textContent : '', text: document.body ? document.body.innerText : ''});
        })()
    """

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun load(context: Context, url: String): Page? = withContext(Dispatchers.Main) {
        var webView: WebView? = null
        val result = withTimeoutOrNull(35_000) {
            suspendCancellableCoroutine { cont ->
                val handler = Handler(Looper.getMainLooper())
                val wv = WebView(context.applicationContext)
                webView = wv
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                var attempts = 0
                var started = false
                var best: Page? = null

                fun finish(p: Page?) {
                    if (cont.isActive) cont.resume(p)
                }

                fun poll() {
                    if (!cont.isActive) return
                    wv.evaluateJavascript(JS) { raw ->
                        val page = runCatching {
                            val json = JSONObject(JSONTokener(raw).nextValue() as String)
                            val ld = json.optJSONArray("ld") ?: JSONArray()
                            val blocks = (0 until ld.length()).map { ld.optString(it) }.toMutableList()
                            val next = json.optString("next")
                            if (next.isNotBlank()) blocks += next
                            Page(blocks, json.optString("text"))
                        }.getOrNull()
                        if (page != null) best = page
                        val hasRecipe = page?.ldJson?.any { it.contains("Recipe") } == true
                        attempts++
                        if (hasRecipe || attempts >= 12) finish(best)
                        else handler.postDelayed({ poll() }, 1000)
                    }
                }

                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, u: String?) {
                        if (!started) {
                            started = true
                            handler.postDelayed({ poll() }, 800)
                        }
                    }
                }
                wv.loadUrl(url)
            }
        }
        webView?.let { it.stopLoading(); it.destroy() }
        result
    }
}
