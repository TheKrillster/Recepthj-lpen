package se.krillster.recepthjalpen.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import se.krillster.recepthjalpen.data.IngredientText
import se.krillster.recepthjalpen.data.Recipe
import java.io.File
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

private val sv = Locale("sv", "SE")

@Composable
fun RecipeImage(path: String?, modifier: Modifier) {
    if (path == null) return
    AsyncImage(
        model = if (path.startsWith("http")) path else File(path),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier
    )
}

// ============================ Receptlistan ============================

@Composable
fun RecipesScreen(vm: AppViewModel, modifier: Modifier, onOpen: (String) -> Unit, onNew: () -> Unit) {
    val data by vm.data.collectAsStateWithLifecycle()
    val imp by vm.importState.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var onlyFav by rememberSaveable { mutableStateOf(false) }
    var tagFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    val tags = remember(data.recipes) {
        data.recipes.flatMap { it.tags }.groupingBy { it }.eachCount().entries
            .sortedByDescending { it.value }.take(15).map { it.key }
    }
    val q = query.trim().lowercase(sv)
    val list = data.recipes
        .filter { !onlyFav || it.favorite }
        .filter { tagFilter == null || tagFilter in it.tags }
        .filter { r ->
            q.isEmpty() || r.title.lowercase(sv).contains(q) ||
                r.tags.any { it.contains(q) } || r.ingredients.any { it.name.lowercase(sv).contains(q) }
        }
        .sortedWith(compareByDescending<Recipe> { it.favorite }.thenBy { it.title.lowercase(sv) })

    Box(modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
            item {
                Text("Recepthjälpen", style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Sök recept eller ingrediens") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, "Rensa") } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp)
                )
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = onlyFav, onClick = { onlyFav = !onlyFav }, label = { Text("♥ Favoriter") }) }
                    items(tags) { t ->
                        FilterChip(selected = tagFilter == t, onClick = { tagFilter = if (tagFilter == t) null else t }, label = { Text(t) })
                    }
                }
            }
            if (imp.running || imp.total > 0) item { ImportBanner(vm, imp) }
            busy?.let { b ->
                item {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp)); Text(b)
                    }
                }
            }
            if (data.recipes.isEmpty() && !imp.running) {
                item {
                    Column(Modifier.padding(24.dp)) {
                        Text("Inga recept ännu", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("Tryck på \"Lägg till\" för att läsa in din mapp med receptbilder, fotografera ett recept, välja bilder eller klistra in en webbadress.\n\nDu kan också dela en receptsida från webbläsaren direkt till Recepthjälpen.\n\nFör att tolka bilder behöver du en Claude API-nyckel under Inställningar.")
                    }
                }
            }
            items(list, key = { it.id }) { r -> RecipeRow(r, onClick = { onOpen(r.id) }) }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("Lägg till") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }
    if (showAdd) AddRecipeDialog(vm, onDismiss = { showAdd = false }, onNew = { showAdd = false; onNew() }, onOpen = onOpen)
}

@Composable
private fun RecipeRow(r: Recipe, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(60.dp).clip(RoundedCornerShape(10.dp))) {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                Text(r.title.take(1).uppercase(), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            }
            RecipeImage(r.imagePath, Modifier.fillMaxSize())
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val meta = listOfNotNull(
                r.timeMinutes?.let { "$it min" },
                "${r.servings} port",
                r.tags.take(3).joinToString(" · ").ifEmpty { null }
            ).joinToString("  ·  ")
            Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (r.favorite) Icon(Icons.Filled.Favorite, "Favorit", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ImportBanner(vm: AppViewModel, imp: ImportState) {
    Card(Modifier.fillMaxWidth().padding(16.dp, 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp)) {
            if (imp.running) {
                Text("Läser in bild ${imp.done + 1} av ${imp.total}", fontWeight = FontWeight.SemiBold)
                Text(imp.current, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { if (imp.total == 0) 0f else imp.done.toFloat() / imp.total }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("${imp.found} recept hittade hittills. Ha appen öppen tills den är klar.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.cancelImport() }) { Text("Avbryt") }
            } else {
                Text("Inläsningen är klar: ${imp.found} nya recept" + if (imp.skipped > 0) ", ${imp.skipped} fanns redan." else ".", fontWeight = FontWeight.SemiBold)
                imp.errors.take(5).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                if (imp.errors.size > 5) Text("…och ${imp.errors.size - 5} till", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.dismissImportSummary() }) { Text("OK") }
            }
        }
    }
}

@Composable
private fun AddRecipeDialog(vm: AppViewModel, onDismiss: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    val data by vm.data.collectAsStateWithLifecycle()
    var url by remember { mutableStateOf("") }
    var cameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            vm.importFolder(uri)
            onDismiss()
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { uris ->
        if (uris.isNotEmpty()) { vm.importPickedImages(uris); onDismiss() }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) { vm.importPickedImages(listOf(u)); onDismiss() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lägg till recept") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (data.settings.folderUri != null) {
                    FilledTonalButton(onClick = { vm.rescanFolder(); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Läs in nya bilder från mappen")
                    }
                }
                OutlinedButton(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (data.settings.folderUri == null) "Läs in en mapp med bilder" else "Välj en annan mapp")
                }
                OutlinedButton(onClick = {
                    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
                    val f = File(dir, "foto-${UUID.randomUUID()}.jpg")
                    val u = FileProvider.getUriForFile(context, context.packageName + ".files", f)
                    cameraUri = u
                    camera.launch(u)
                }, modifier = Modifier.fillMaxWidth()) { Text("Fotografera ett recept") }
                OutlinedButton(onClick = {
                    imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, modifier = Modifier.fillMaxWidth()) { Text("Välj bilder") }
                OutlinedButton(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Skriv in själv") }
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Webbadress till recept") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                FilledTonalButton(enabled = url.isNotBlank(), onClick = {
                    vm.importUrl(url) { id -> if (id != null) onOpen(id) }
                    onDismiss()
                }, modifier = Modifier.fillMaxWidth()) { Text("Hämta från webben") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Stäng") } }
    )
}

// ============================ Receptvy ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeDetailScreen(
    vm: AppViewModel,
    recipeId: String,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
) {
    val data by vm.data.collectAsStateWithLifecycle()
    val r = data.recipes.firstOrNull { it.id == recipeId }
    if (r == null) { androidx.compose.runtime.LaunchedEffect(Unit) { onBack() }; return }
    var servings by remember(r.id) { mutableIntStateOf(r.servings) }
    var confirmDelete by remember { mutableStateOf(false) }
    var pickDay by remember { mutableStateOf(false) }
    val factor = servings.toDouble() / r.servings.coerceAtLeast(1)
    val context = LocalContext.current

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(r.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Tillbaka") } },
                actions = {
                    IconButton(onClick = { vm.toggleFavorite(r.id) }) {
                        Icon(if (r.favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorit")
                    }
                    IconButton(onClick = { onEdit(r.id) }) { Icon(Icons.Filled.Edit, "Redigera") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Ta bort") }
                }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 32.dp)) {
            if (r.imagePath != null) item {
                RecipeImage(r.imagePath, Modifier.fillMaxWidth().heightIn(max = 260.dp).height(220.dp)
                    .clickable {
                        if (!r.imagePath.startsWith("http")) runCatching {
                            val u = FileProvider.getUriForFile(context, context.packageName + ".files", File(r.imagePath))
                            context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/jpeg")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        }
                    })
            }
            item {
                Column(Modifier.padding(16.dp)) {
                    Text(r.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    val meta = listOfNotNull(r.timeMinutes?.let { "⏱ $it min" }, r.tags.joinToString(" · ").ifEmpty { null }).joinToString("   ")
                    if (meta.isNotEmpty()) Text(meta, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Portioner", modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(onClick = { if (servings > 1) servings-- }) { Text("−") }
                        Text("$servings", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleLarge)
                        OutlinedButton(onClick = { servings++ }) { Text("+") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = { vm.addRecipeToShopping(r, servings) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.ShoppingCart, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Handla")
                        }
                        FilledTonalButton(onClick = { pickDay = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.DateRange, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Veckomeny")
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Ingredienser", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
            items(r.ingredients) { i ->
                val amount = IngredientText.formatAmount(i.amount?.times(factor))
                Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(listOf(amount, i.unit).filter { it.isNotBlank() }.joinToString(" "),
                        Modifier.width(90.dp), fontWeight = FontWeight.SemiBold)
                    Text(i.name + if (i.note.isNotBlank()) ", ${i.note}" else "")
                }
            }
            item {
                Text("Gör så här", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(16.dp, 20.dp, 16.dp, 8.dp))
            }
            itemsIndexed(r.steps) { idx, s ->
                Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text("${idx + 1}.", Modifier.width(28.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(s)
                }
            }
            if (r.notes.isNotBlank()) item {
                Text("Anteckningar", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp))
                Text(r.notes, Modifier.padding(horizontal = 16.dp))
            }
            if (r.source.isNotBlank()) item {
                val isUrl = r.source.startsWith("http")
                Text("Källa: ${r.source}", style = MaterialTheme.typography.bodySmall,
                    color = if (isUrl) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp).then(
                        if (isUrl) Modifier.clickable {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.source))) }
                        } else Modifier
                    ))
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Ta bort receptet?") },
        text = { Text("\"${r.title}\" tas bort permanent.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteRecipe(r.id); onBack() }) { Text("Ta bort") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Avbryt") } }
    )

    if (pickDay) {
        val start = LocalDate.now()
        AlertDialog(
            onDismissRequest = { pickDay = false },
            title = { Text("Vilken dag?") },
            text = {
                LazyColumn {
                    items((0..13).map { start.plusDays(it.toLong()) }) { d ->
                        val current = data.menu[d.toString()]?.recipeId?.let { id -> data.recipes.firstOrNull { it.id == id }?.title }
                        Column(Modifier.fillMaxWidth().clickable {
                            vm.setMenu(d, r.id, servings); pickDay = false
                            vm.say("${r.title} lades in ${dayLabel(d)}.")
                        }.padding(vertical = 10.dp)) {
                            Text(dayLabel(d), fontWeight = FontWeight.SemiBold)
                            if (current != null) Text("Ersätter: $current", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickDay = false }) { Text("Avbryt") } }
        )
    }
}

fun dayLabel(d: LocalDate): String {
    val name = d.dayOfWeek.getDisplayName(TextStyle.FULL, sv).replaceFirstChar { it.uppercase() }
    return "$name ${d.dayOfMonth} ${d.month.getDisplayName(TextStyle.SHORT, sv).trimEnd('.')}"
}

// ============================ Redigera ============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeEditScreen(vm: AppViewModel, recipeId: String?, onDone: (String?) -> Unit) {
    val data by vm.data.collectAsStateWithLifecycle()
    val original = remember(recipeId) {
        data.recipes.firstOrNull { it.id == recipeId }
            ?: Recipe(id = UUID.randomUUID().toString(), title = "", servings = data.settings.defaultServings)
    }
    var title by rememberSaveable { mutableStateOf(original.title) }
    var servings by rememberSaveable { mutableStateOf(original.servings.toString()) }
    var time by rememberSaveable { mutableStateOf(original.timeMinutes?.toString() ?: "") }
    var tags by rememberSaveable { mutableStateOf(original.tags.joinToString(", ")) }
    var ingredients by rememberSaveable { mutableStateOf(original.ingredients.joinToString("\n") { IngredientText.toLine(it) }) }
    var steps by rememberSaveable { mutableStateOf(original.steps.joinToString("\n\n")) }
    var notes by rememberSaveable { mutableStateOf(original.notes) }

    fun save() {
        val oldByLine = original.ingredients.associateBy { IngredientText.toLine(it) }
        val r = original.copy(
            title = title.trim().ifEmpty { "Namnlöst recept" },
            servings = servings.toIntOrNull()?.coerceAtLeast(1) ?: 4,
            timeMinutes = time.toIntOrNull(),
            tags = tags.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() },
            ingredients = ingredients.lines().map { it.trim() }.filter { it.isNotEmpty() }
                .map { line -> oldByLine[line] ?: IngredientText.parse(line) },
            steps = steps.split(Regex("\n\\s*\n")).map { it.replace('\n', ' ').trim() }.filter { it.isNotEmpty() },
            notes = notes.trim(),
        )
        vm.saveRecipe(r)
        onDone(r.id)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (recipeId == null) "Nytt recept" else "Redigera") },
            navigationIcon = { IconButton(onClick = { onDone(recipeId) }) { Icon(Icons.Filled.Close, "Avbryt") } },
            actions = { TextButton(onClick = { save() }) { Text("Spara") } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(title, { title = it }, label = { Text("Namn") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(servings, { servings = it.filter(Char::isDigit) }, label = { Text("Portioner") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(time, { time = it.filter(Char::isDigit) }, label = { Text("Tid (min)") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            OutlinedTextField(tags, { tags = it }, label = { Text("Taggar (komma emellan)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(ingredients, { ingredients = it }, label = { Text("Ingredienser, en per rad (t.ex. 2 dl grädde)") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp))
            OutlinedTextField(steps, { steps = it }, label = { Text("Gör så här (tom rad mellan stegen)") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp))
            OutlinedTextField(notes, { notes = it }, label = { Text("Anteckningar") }, modifier = Modifier.fillMaxWidth())
        }
    }
}
