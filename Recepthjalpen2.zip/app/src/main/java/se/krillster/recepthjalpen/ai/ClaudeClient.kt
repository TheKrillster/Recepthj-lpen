package se.krillster.recepthjalpen.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import se.krillster.recepthjalpen.data.Categories
import se.krillster.recepthjalpen.data.Ingredient
import se.krillster.recepthjalpen.data.Recipe
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class ClaudeException(message: String) : Exception(message)

class ClaudeClient(private val apiKey: String, private val model: String) {

    private suspend fun send(system: String, content: JSONArray, maxTokens: Int): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw ClaudeException("Lägg in din Claude API-nyckel under Inställningar först.")
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            .toString()

        var attempt = 0
        while (true) {
            attempt++
            val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 30_000
                readTimeout = 240_000
                setRequestProperty("x-api-key", apiKey.trim())
                setRequestProperty("anthropic-version", "2023-06-01")
                setRequestProperty("content-type", "application/json")
            }
            try {
                conn.outputStream.use { it.write(body.toByteArray()) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                if (code in 200..299) {
                    val arr = JSONObject(text).getJSONArray("content")
                    return@withContext buildString {
                        for (i in 0 until arr.length()) {
                            val block = arr.getJSONObject(i)
                            if (block.optString("type") == "text") append(block.optString("text"))
                        }
                    }
                }
                val retry = code == 429 || code == 529 || code >= 500
                if (retry && attempt < 4) {
                    delay(3000L * attempt)
                    continue
                }
                throw ClaudeException(friendlyError(code, text))
            } finally {
                conn.disconnect()
            }
        }
        throw IllegalStateException()
    }

    private fun friendlyError(code: Int, body: String): String {
        val msg = runCatching { JSONObject(body).getJSONObject("error").optString("message") }.getOrDefault(body.take(200))
        return when {
            code == 401 -> "API-nyckeln godkändes inte. Kontrollera den under Inställningar."
            msg.contains("credit balance", ignoreCase = true) -> "Slut på krediter i ditt Claude-konto. Fyll på på platform.claude.com."
            code == 404 || msg.contains("model", ignoreCase = true) && code == 400 -> "Modellen \"$model\" hittades inte. Byt modell under Inställningar. ($msg)"
            code == 429 -> "För många anrop just nu. Försök igen om en stund."
            else -> "Claude svarade med fel $code: $msg"
        }
    }

    // ---------- Recept ----------

    suspend fun recipesFromImage(base64Jpeg: String): List<Recipe> {
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source", JSONObject()
                .put("type", "base64").put("media_type", "image/jpeg").put("data", base64Jpeg)))
            .put(JSONObject().put("type", "text").put("text", "Läs av receptet/recepten i bilden."))
        return parseRecipes(send(RECIPE_SYSTEM, content, 6000))
    }

    suspend fun recipesFromText(pageText: String, url: String): List<Recipe> {
        val content = JSONArray().put(JSONObject().put("type", "text").put("text",
            "Här är texten från webbsidan $url. Plocka ut receptet/recepten.\n\n$pageText"))
        return parseRecipes(send(RECIPE_SYSTEM, content, 6000)).map { it.copy(source = url) }
    }

    private fun parseRecipes(text: String): List<Recipe> {
        val obj = extractJson(text)
        val arr = obj.optJSONArray("recipes") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i -> recipeFromJson(arr.optJSONObject(i)) }
    }

    // ---------- Veckomeny ----------

    data class DaySuggestion(val date: String, val recipeId: String?, val newRecipe: Recipe?, val reason: String)

    suspend fun suggestWeek(
        dates: List<String>,
        recipes: List<Recipe>,
        recentlyUsed: List<String>,
        preferences: String,
        newIdeas: Int,
        servings: Int,
        month: String,
    ): List<DaySuggestion> {
        val catalog = recipes.joinToString("\n") { r ->
            "${r.id} | ${r.title} | ${r.tags.joinToString(", ")} | ${r.timeMinutes?.let { "$it min" } ?: "?"}" +
                (if (r.favorite) " | favorit" else "")
        }
        val prompt = """
            Planera middagar för dessa datum: ${dates.joinToString(", ")}.
            Månad: $month. Portioner: $servings.
            Önskemål från familjen: ${preferences.ifBlank { "inga särskilda" }}
            Antal helt nya receptidéer (som inte finns i samlingen) att ta med: ${if (recipes.isEmpty()) dates.size else newIdeas}
            Recept som ätits nyligen (undvik helst): ${recentlyUsed.joinToString(", ").ifBlank { "inga" }}

            Receptsamlingen (id | titel | taggar | tid):
            ${catalog.ifBlank { "(tom)" }}
        """.trimIndent()
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", prompt))
        val obj = extractJson(send(WEEK_SYSTEM, content, 12000))
        val days = obj.optJSONArray("days") ?: return emptyList()
        val validIds = recipes.map { it.id }.toSet()
        return (0 until days.length()).mapNotNull { i ->
            val d = days.optJSONObject(i) ?: return@mapNotNull null
            val id = d.optString("recipeId").takeIf { it.isNotBlank() && it != "null" && it in validIds }
            val newRecipe = d.optJSONObject("newRecipe")?.let { recipeFromJson(it) }
                ?.let { it.copy(tags = (it.tags + "förslag").distinct(), source = "Förslag från Claude") }
            if (id == null && newRecipe == null) null
            else DaySuggestion(d.optString("date"), id, newRecipe, d.optString("reason"))
        }
    }

    companion object {
        fun extractJson(text: String): JSONObject {
            val start = text.indexOf('{')
            val end = text.lastIndexOf('}')
            if (start < 0 || end <= start) throw ClaudeException("Kunde inte tolka svaret från Claude.")
            return runCatching { JSONObject(text.substring(start, end + 1)) }
                .getOrElse { throw ClaudeException("Svaret från Claude var inte giltig JSON (kanske för långt).") }
        }

        fun recipeFromJson(o: JSONObject?): Recipe? {
            o ?: return null
            val title = o.optString("title").trim()
            val ingArr = o.optJSONArray("ingredients") ?: JSONArray()
            val ingredients = (0 until ingArr.length()).mapNotNull { i ->
                val ig = ingArr.optJSONObject(i) ?: return@mapNotNull null
                val name = ig.optString("name").trim()
                if (name.isEmpty()) return@mapNotNull null
                val amount = when (val a = ig.opt("amount")) {
                    is Number -> a.toDouble()
                    is String -> a.replace(',', '.').toDoubleOrNull()
                    else -> null
                }
                Ingredient(
                    name = name,
                    amount = amount,
                    unit = ig.optString("unit").takeIf { it != "null" }?.trim() ?: "",
                    note = ig.optString("note").takeIf { it != "null" }?.trim() ?: "",
                    category = Categories.normalize(ig.optString("category"), name),
                )
            }
            val stepsArr = o.optJSONArray("steps") ?: JSONArray()
            val steps = (0 until stepsArr.length()).map { stepsArr.optString(it).trim() }.filter { it.isNotEmpty() }
            if (title.isEmpty() && ingredients.isEmpty() && steps.isEmpty()) return null
            val tagsArr = o.optJSONArray("tags") ?: JSONArray()
            return Recipe(
                id = UUID.randomUUID().toString(),
                title = title.ifEmpty { "Namnlöst recept" },
                servings = o.optInt("servings", 4).takeIf { it > 0 } ?: 4,
                timeMinutes = o.optInt("timeMinutes", 0).takeIf { it > 0 },
                ingredients = ingredients,
                steps = steps,
                tags = (0 until tagsArr.length()).map { tagsArr.optString(it).trim().lowercase() }.filter { it.isNotEmpty() },
                notes = o.optString("notes").takeIf { it != "null" } ?: "",
            )
        }

        private val CATS = Categories.ALL.joinToString(", ") { "\"$it\"" }

        private val RECIPE_FORMAT = """
            {"title":"Krämig kycklinggryta","servings":4,"timeMinutes":30,
             "ingredients":[{"name":"gul lök","amount":1,"unit":"st","note":"finhackad","category":"Frukt & grönt"}],
             "steps":["Hacka löken.","Stek kycklingen."],
             "tags":["vardag","kyckling"],"notes":""}
        """.trimIndent()

        val RECIPE_SYSTEM = """
            Du läser av recept från bilder och webbsidor och gör om dem till strukturerad data på svenska.
            Svara ENDAST med JSON, utan annan text, i formatet {"recipes":[ ... ]} där varje recept ser ut så här:
            $RECIPE_FORMAT

            Regler:
            - Skriv allt på svenska. Översätt om receptet är på ett annat språk.
            - Använd svenska enheter: g, kg, ml, dl, l, msk, tsk, krm, st, förp, burk, påse, klyfta, knippe, kruka, skiva, nypa. Räkna om cups, oz, lb, tbsp, tsp.
            - amount är ett tal (0.5 för ½) eller null om ingen mängd anges. Vid intervall, ta det lägre.
            - name är varan som den heter i en inköpslista, i grundform ("gul lök", "kycklingfilé"). Beredning och detaljer läggs i note ("finhackad", "rumsvarm").
            - category är exakt en av: $CATS.
            - servings: antal portioner enligt receptet, annars en rimlig uppskattning. timeMinutes: total tid om den anges eller kan uppskattas.
            - steps: ett steg per element, i ordning, utan numrering.
            - tags: 1–5 korta taggar med små bokstäver, t.ex. typ av rätt, huvudingrediens, "vegetariskt", "snabbt", "bakning", "efterrätt", "fest".
            - Flera recept i bilden: ta med alla. Inget recept alls: svara {"recipes":[]}.
            - Ofullständigt recept (t.ex. bara en av två sidor): ta med det som syns och lägg till taggen "ofullständig".
            - Handskrift: tolka så gott det går och markera osäkra ord med [?].
        """.trimIndent()

        val WEEK_SYSTEM = """
            Du är en hjälpsam matplanerare för en svensk familj. Du planerar en middag per datum.
            Välj främst ur familjens egen receptsamling (använd exakt receptets id), och föreslå dessutom det antal nya recept som efterfrågas.
            Tänk på variation (inte samma huvudingrediens flera dagar i rad), säsong, snabbare rätter på vardagar och gärna något extra på helgen.
            Ta hänsyn till familjens önskemål.
            Svara ENDAST med JSON i formatet:
            {"days":[{"date":"2026-01-05","recipeId":"<id ur samlingen eller null>","newRecipe":null,"reason":"kort motivering"}]}
            För ett nytt recept: sätt recipeId till null och newRecipe till ett komplett recept i detta format:
            $RECIPE_FORMAT
            Samma regler för ingredienser gäller: svenska enheter, name i grundform, category exakt en av: $CATS.
        """.trimIndent()
    }
}
