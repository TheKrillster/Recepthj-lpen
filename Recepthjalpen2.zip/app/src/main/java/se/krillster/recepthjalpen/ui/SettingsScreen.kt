package se.krillster.recepthjalpen.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.LocalDate

private val MODELS = listOf(
    "claude-sonnet-5-5" to "Sonnet 5.5 – bäst på foton och handskrift (ca 10 öre/recept)",
    "claude-haiku-5-5" to "Haiku 5.5 – billigast (under 1 öre/recept)",
)

@Composable
fun SettingsScreen(vm: AppViewModel, modifier: Modifier) {
    val data by vm.data.collectAsStateWithLifecycle()
    val s = data.settings
    val context = LocalContext.current
    var showKey by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { vm.exportBackup(it) }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importBackup(it) }
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Inställningar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary)

        Section("Claude")
        OutlinedTextField(
            value = s.apiKey, onValueChange = { v -> vm.updateSettings { it.copy(apiKey = v.trim()) } },
            label = { Text("API-nyckel (sk-ant-…)") }, singleLine = true,
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Dölj" else "Visa") } },
            modifier = Modifier.fillMaxWidth()
        )
        Text("Skapa en nyckel och fyll på krediter på platform.claude.com. Det betalas separat från Claude-abonnemanget. Nyckeln sparas bara på telefonen.",
            style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://platform.claude.com/settings/keys"))) }
        }) { Text("Öppna platform.claude.com") }

        Text("Modell", style = MaterialTheme.typography.titleSmall)
        MODELS.forEach { (id, label) ->
            Row(Modifier.fillMaxWidth().clickable { vm.updateSettings { it.copy(model = id) } },
                verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = s.model == id, onClick = { vm.updateSettings { it.copy(model = id) } })
                Text(label)
            }
        }
        OutlinedTextField(s.model, { v -> vm.updateSettings { it.copy(model = v.trim()) } },
            label = { Text("Modellnamn (avancerat)") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        HorizontalDivider()
        Section("Veckomeny")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Portioner som standard", Modifier.weight(1f))
            OutlinedButton(onClick = { vm.updateSettings { it.copy(defaultServings = (it.defaultServings - 1).coerceAtLeast(1)) } }) { Text("−") }
            Text("${s.defaultServings}", Modifier.padding(horizontal = 12.dp))
            OutlinedButton(onClick = { vm.updateSettings { it.copy(defaultServings = it.defaultServings + 1) } }) { Text("+") }
        }
        OutlinedTextField(
            s.preferences, { v -> vm.updateSettings { it.copy(preferences = v) } },
            label = { Text("Önskemål till veckoförslagen") },
            placeholder = { Text("T.ex. vegetariskt två dagar i veckan, fisk en gång, snabbt på vardagar, inga svampar") },
            minLines = 3, modifier = Modifier.fillMaxWidth()
        )
        Text("Nya receptidéer per vecka: ${s.newIdeasPerWeek}")
        Slider(
            value = s.newIdeasPerWeek.toFloat(),
            onValueChange = { v -> vm.updateSettings { it.copy(newIdeasPerWeek = v.toInt()) } },
            valueRange = 0f..7f, steps = 6
        )
        Text("0 = bara dina egna recept. Nya förslag sparas med taggen \"förslag\" så du kan ta bort dem du inte gillar.",
            style = MaterialTheme.typography.bodySmall)

        HorizontalDivider()
        Section("Inköpslista")
        OutlinedTextField(
            s.pantryStaples, { v -> vm.updateSettings { it.copy(pantryStaples = v) } },
            label = { Text("Basvaror som inte läggs på listan (komma emellan)") },
            modifier = Modifier.fillMaxWidth()
        )
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("ICA och Willys", fontWeight = FontWeight.SemiBold)
                Text("Priser och veckans erbjudanden kommer i nästa steg.", style = MaterialTheme.typography.bodySmall)
            }
        }

        HorizontalDivider()
        Section("Bilder och säkerhetskopia")
        Text(if (s.folderUri != null) "Bildmapp vald. ${data.importedUris.size} bilder inlästa hittills." else "Ingen bildmapp vald ännu.",
            style = MaterialTheme.typography.bodyMedium)
        if (s.folderUri != null) OutlinedButton(onClick = { vm.rescanFolder() }, modifier = Modifier.fillMaxWidth()) {
            Text("Läs in nya bilder från mappen")
        }
        OutlinedButton(onClick = { exportLauncher.launch("recepthjalpen-${LocalDate.now()}.json") }, modifier = Modifier.fillMaxWidth()) {
            Text("Spara säkerhetskopia (${data.recipes.size} recept)")
        }
        OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Läs in säkerhetskopia")
        }
        Text("Spara säkerhetskopian i t.ex. Dropbox eller Google Drive så har du kvar recepten om du byter telefon.",
            style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold)
}
