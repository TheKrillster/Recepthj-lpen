package se.krillster.recepthjalpen

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import se.krillster.recepthjalpen.ui.AppViewModel
import se.krillster.recepthjalpen.ui.MenuScreen
import se.krillster.recepthjalpen.ui.RecipeDetailScreen
import se.krillster.recepthjalpen.ui.RecipeEditScreen
import se.krillster.recepthjalpen.ui.RecipesScreen
import se.krillster.recepthjalpen.ui.SettingsScreen
import se.krillster.recepthjalpen.ui.ShoppingScreen

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleShare(intent)
        setContent { RecepthjalpenTheme { App(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleShare(intent: Intent?) {
        intent ?: return
        when (intent.action) {
            Intent.ACTION_SEND -> {
                if (intent.type?.startsWith("image/") == true) {
                    val uri: Uri? = if (Build.VERSION.SDK_INT >= 33)
                        intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                    else intent.getParcelableExtra(Intent.EXTRA_STREAM)
                    uri?.let { vm.importPickedImages(listOf(it)) }
                } else {
                    val text = listOfNotNull(
                        intent.getStringExtra(Intent.EXTRA_TEXT),
                        intent.getStringExtra(Intent.EXTRA_SUBJECT)
                    ).joinToString(" ")
                    vm.importUrl(text)
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val uris: List<Uri>? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                uris?.let { vm.importPickedImages(it) }
            }
        }
    }
}

private val Green = Color(0xFF2E5E3A)

@Composable
fun RecepthjalpenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFCFE8D2),
            onPrimaryContainer = Color(0xFF0E2614),
            secondary = Color(0xFFB8860B),
            secondaryContainer = Color(0xFFFFE8B5),
            background = Color(0xFFFFFBF6),
            surface = Color(0xFFFFFBF6),
            surfaceVariant = Color(0xFFF1ECE4),
        ),
        content = content
    )
}

enum class Tab(val label: String, val icon: ImageVector) {
    RECIPES("Recept", Icons.AutoMirrored.Filled.List),
    MENU("Veckomeny", Icons.Filled.DateRange),
    SHOPPING("Inköp", Icons.Filled.ShoppingCart),
    SETTINGS("Inställningar", Icons.Filled.Settings),
}

@Composable
fun App(vm: AppViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.RECIPES) }
    var openRecipeId by rememberSaveable { mutableStateOf<String?>(null) }
    var editRecipeId by rememberSaveable { mutableStateOf<String?>(null) } // "new" = nytt recept

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        vm.messages.collect { msg ->
            snackbar.showSnackbar(msg, withDismissAction = true, duration = SnackbarDuration.Long)
        }
    }

    BackHandler(enabled = editRecipeId != null || openRecipeId != null || tab != Tab.RECIPES) {
        when {
            editRecipeId != null -> editRecipeId = null
            openRecipeId != null -> openRecipeId = null
            else -> tab = Tab.RECIPES
        }
    }

    when {
        editRecipeId != null -> RecipeEditScreen(
            vm = vm,
            recipeId = editRecipeId!!.takeIf { it != "new" },
            onDone = { savedId ->
                editRecipeId = null
                if (savedId != null) openRecipeId = savedId
            }
        )
        openRecipeId != null -> RecipeDetailScreen(
            vm = vm,
            recipeId = openRecipeId!!,
            snackbar = snackbar,
            onBack = { openRecipeId = null },
            onEdit = { editRecipeId = it },
        )
        else -> Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        ) { pad ->
            val m = Modifier.padding(pad)
            when (tab) {
                Tab.RECIPES -> RecipesScreen(vm, m, onOpen = { openRecipeId = it }, onNew = { editRecipeId = "new" })
                Tab.MENU -> MenuScreen(vm, m, onOpen = { openRecipeId = it })
                Tab.SHOPPING -> ShoppingScreen(vm, m)
                Tab.SETTINGS -> SettingsScreen(vm, m)
            }
        }
    }
}
