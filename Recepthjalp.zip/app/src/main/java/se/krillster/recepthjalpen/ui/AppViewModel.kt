package se.krillster.recepthjalpen.ui

import android.app.Application
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import se.krillster.recepthjalpen.ai.ClaudeClient
import se.krillster.recepthjalpen.ai.ImageUtil
import se.krillster.recepthjalpen.ai.WebImporter
import se.krillster.recepthjalpen.ai.WebViewLoader
import se.krillster.recepthjalpen.data.AppData
import se.krillster.recepthjalpen.data.IngredientText
import se.krillster.recepthjalpen.data.MenuEntry
import se.krillster.recepthjalpen.data.Recipe
import se.krillster.recepthjalpen.data.Repository
import se.krillster.recepthjalpen.data.Settings
import se.krillster.recepthjalpen.data.ShoppingItem
import java.io.File
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

data class ImportState(
    val running: Boolean = false,
    val total: Int = 0,
    val done: Int = 0,
    val current: String = "",
    val found: Int = 0,
    val skipped: Int = 0,
    val errors: List<String> = emptyList(),
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val repo = Repository(File(app.filesDir, "recepthjalpen.json"))
    val data: StateFlow<AppData> = repo.data

    private val _import = MutableStateFlow(ImportState())
    val importState: StateFlow<ImportState> = _import

    private val _busy = MutableStateFlow<String?>(null)
    val busy: StateFlow<String?> = _busy

    // Kanal i stället för state, så att varje meddelande visas en gång och inte försvinner direkt
    private val _messages = kotlinx.coroutines.channels.Channel<String>(kotlinx.coroutines.channels.Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()
    fun say(msg: String) { _messages.trySend(msg) }

    private var importJob: Job? = null

    init {
        repo.normalize = ::syncShopping
        repo.update { it } // synka listan direkt vid start (veckan kan ha bytts)
    }

    private val ctx get() = getApplication<Application>()
    private fun claude() = data.value.settings.let { ClaudeClient(it.apiKey, it.model) }

    // ---------------- Recept ----------------

    fun saveRecipe(r: Recipe) = repo.update { d ->
        if (d.recipes.any { it.id == r.id }) d.copy(recipes = d.recipes.map { if (it.id == r.id) r else it })
        else d.copy(recipes = d.recipes + r)
    }

    fun deleteRecipe(id: String) = repo.update { d ->
        d.recipes.firstOrNull { it.id == id }?.imagePath?.let { p ->
            if (!p.startsWith("http") && d.recipes.count { it.imagePath == p } == 1) File(p).delete()
        }
        d.copy(
            recipes = d.recipes.filter { it.id != id },
            menu = d.menu.filterValues { it.recipeId != id },
        )
    }

    fun toggleFavorite(id: String) = repo.update { d ->
        d.copy(recipes = d.recipes.map { if (it.id == id) it.copy(favorite = !it.favorite) else it })
    }

    /** Lägger till nya recept men hoppar över sådana med samma namn som redan finns. */
    private fun addRecipes(list: List<Recipe>): Pair<Int, Int> {
        var added = 0
        var skipped = 0
        repo.update { d ->
            val existing = d.recipes.map { it.title.lowercase().trim() }.toMutableSet()
            val fresh = list.filter { r ->
                val key = r.title.lowercase().trim()
                (key !in existing || key == "namnlöst recept").also { if (it) existing += key }
            }
            added = fresh.size
            skipped = list.size - fresh.size
            d.copy(recipes = d.recipes + fresh)
        }
        return added to skipped
    }

    // ---------------- Inläsning från bilder ----------------

    data class ImageSource(val uri: Uri, val name: String, val rememberKey: String?)

    fun importFolder(treeUri: Uri) {
        repo.update { it.copy(settings = it.settings.copy(folderUri = treeUri.toString())) }
        rescanFolder()
    }

    fun rescanFolder() {
        val uriStr = data.value.settings.folderUri ?: return say("Välj en mapp först.")
        if (data.value.settings.apiKey.isBlank()) { _alert.value = "För att tolka bilder behövs en Claude API-nyckel. Lägg in den under Inställningar."; return }
        viewModelScope.launch {
            val images = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(ctx, Uri.parse(uriStr)) ?: return@withContext emptyList()
                fun walk(dir: DocumentFile, depth: Int): List<DocumentFile> = dir.listFiles().flatMap { f ->
                    when {
                        f.isDirectory && depth < 3 -> walk(f, depth + 1)
                        f.type?.startsWith("image/") == true -> listOf(f)
                        else -> emptyList()
                    }
                }
                walk(root, 0).sortedBy { it.name ?: "" }
            }
            val already = data.value.importedUris
            val todo = images.filter { it.uri.toString() !in already }
                .map { ImageSource(it.uri, it.name ?: "bild", it.uri.toString()) }
            if (todo.isEmpty()) {
                say(if (images.isEmpty()) "Hittade inga bilder i mappen." else "Inga nya bilder. Alla ${images.size} är redan inlästa.")
                return@launch
            }
            importImages(todo)
        }
    }

    fun importPickedImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        if (data.value.settings.apiKey.isBlank()) { _alert.value = "För att tolka bilder behövs en Claude API-nyckel. Lägg in den under Inställningar."; return }
        importImages(uris.mapIndexed { i, u -> ImageSource(u, "Bild ${i + 1}", null) })
    }

    private fun importImages(list: List<ImageSource>) {
        if (importJob?.isActive == true) return say("En inläsning pågår redan.")
        importJob = viewModelScope.launch {
            _import.value = ImportState(running = true, total = list.size)
            val client = claude()
            for ((index, src) in list.withIndex()) {
                if (!isActive) break
                _import.value = _import.value.copy(current = src.name, done = index)
                try {
                    val bytes = withContext(Dispatchers.IO) { ImageUtil.loadJpeg(ctx, src.uri) }
                    val recipes = client.recipesFromImage(ImageUtil.base64(bytes))
                    if (recipes.isNotEmpty()) {
                        val path = withContext(Dispatchers.IO) {
                            ImageUtil.saveCopy(ctx, bytes, UUID.randomUUID().toString())
                        }
                        val (added, skipped) = addRecipes(recipes.map {
                            it.copy(imagePath = path, source = "Bild: ${src.name}")
                        })
                        _import.value = _import.value.copy(
                            found = _import.value.found + added,
                            skipped = _import.value.skipped + skipped
                        )
                    }
                    src.rememberKey?.let { key -> repo.update { it.copy(importedUris = it.importedUris + key) } }
                } catch (e: Exception) {
                    if (!isActive) break
                    _import.value = _import.value.copy(errors = _import.value.errors + "${src.name}: ${e.message}")
                    if (e.message?.contains("API-nyckel") == true || e.message?.contains("krediter") == true) break
                }
            }
            val s = _import.value
            _import.value = s.copy(running = false, done = s.total)
            say(buildString {
                append("Klart! ${s.found} nya recept.")
                if (s.skipped > 0) append(" ${s.skipped} fanns redan.")
                if (s.errors.isNotEmpty()) append(" ${s.errors.size} bilder gick inte att läsa – de provas igen nästa gång.")
            })
        }
    }

    /** Flera bilder som tillsammans är ett recept (t.ex. tre sidor). */
    fun importOneRecipeFromImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        if (data.value.settings.apiKey.isBlank()) { _alert.value = "För att tolka bilder behövs en Claude API-nyckel. Lägg in den under Inställningar."; return }
        if (urlJob?.isActive == true) return
        urlJob = viewModelScope.launch {
            try {
                _busy.value = "Läser ${uris.size} bilder…"
                val images = withContext(Dispatchers.IO) { uris.take(8).map { ImageUtil.loadJpeg(ctx, it) } }
                _busy.value = "Claude sätter ihop receptet…"
                val recipes = claude().recipesFromImages(images.map { ImageUtil.base64(it) }, onePerAll = true)
                if (recipes.isEmpty()) { _alert.value = "Hittade inget recept i bilderna."; return@launch }
                val path = withContext(Dispatchers.IO) { ImageUtil.saveCopy(ctx, images.first(), UUID.randomUUID().toString()) }
                val r = recipes.first().let { it.copy(imagePath = path, source = "${uris.size} bilder", tags = it.tags - "ofullständig") }
                addRecipes(listOf(r))
                say("Sparade \"${r.title}\" från ${uris.size} bilder.")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _alert.value = e.message ?: "Något gick fel."
            } finally {
                _busy.value = null
            }
        }
    }

    /** Slår ihop två recept, t.ex. när ett recept lästs in som två bilder i mappen. */
    fun mergeRecipes(firstId: String, secondId: String) {
        val d = data.value
        val a = d.recipes.firstOrNull { it.id == firstId } ?: return
        val b = d.recipes.firstOrNull { it.id == secondId } ?: return
        fun weak(t: String) = t.isBlank() || t == "Namnlöst recept"
        val title = if (weak(a.title) && !weak(b.title)) b.title else a.title
        val seen = mutableSetOf<String>()
        val merged = a.copy(
            title = title,
            servings = if (a.ingredients.isEmpty()) b.servings else a.servings,
            timeMinutes = a.timeMinutes ?: b.timeMinutes,
            ingredients = (a.ingredients + b.ingredients).filter { seen.add(IngredientText.toLine(it).lowercase()) },
            steps = a.steps + b.steps,
            tags = (a.tags + b.tags).distinct() - "ofullständig",
            notes = listOf(a.notes, b.notes).filter { it.isNotBlank() }.joinToString("\n"),
            imagePath = a.imagePath ?: b.imagePath,
            favorite = a.favorite || b.favorite,
        )
        repo.update { cur ->
            cur.copy(
                recipes = cur.recipes.filter { it.id != b.id }.map { if (it.id == a.id) merged else it },
                menu = cur.menu.mapValues { (_, e) -> if (e.recipeId == b.id) e.copy(recipeId = a.id) else e },
            )
        }
        say("Recepten slogs ihop till \"$title\".")
    }

    fun rememberImageLocation(uri: Uri) = updateSettings { it.copy(lastImageUri = uri.toString()) }

    /** Var bildväljaren ska öppnas: förra bildens mapp, annars receptmappen. */
    fun initialImageLocation(): Uri? {
        val s = data.value.settings
        s.lastImageUri?.let { return Uri.parse(it) }
        return s.folderUri?.let { tree ->
            runCatching {
                val t = Uri.parse(tree)
                android.provider.DocumentsContract.buildDocumentUriUsingTree(t, android.provider.DocumentsContract.getTreeDocumentId(t))
            }.getOrNull()
        }
    }

    fun cancelImport() {
        importJob?.cancel()
        _import.value = _import.value.copy(running = false)
    }

    fun dismissImportSummary() { _import.value = ImportState() }

    // ---------------- Inläsning från webben ----------------

    private val _alert = MutableStateFlow<String?>(null)
    /** Meddelande som visas i en ruta tills man trycker OK. */
    val alert: StateFlow<String?> = _alert
    fun dismissAlert() { _alert.value = null }

    private var urlJob: Job? = null
    fun cancelBusy() { urlJob?.cancel(); _busy.value = null }

    fun importUrl(input: String, onDone: (String?) -> Unit = {}) {
        val url = WebImporter.findUrl(input)
        if (url == null) { _alert.value = "Hittade ingen webbadress i:\n$input"; return }
        if (urlJob?.isActive == true) return
        urlJob = viewModelScope.launch {
            val log = mutableListOf<String>()
            val t0 = System.currentTimeMillis()
            fun step(s: String) { log += "${(System.currentTimeMillis() - t0) / 1000}s: $s" }
            _busy.value = "Hämtar sidan…"
            try {
                // 1. Vanlig hämtning och inbyggd receptdata
                val html = runCatching { WebImporter.fetch(url) }
                    .onFailure { step("Hämtning misslyckades: ${it.message ?: it.javaClass.simpleName}") }
                    .getOrNull()
                var recipes = emptyList<Recipe>()
                var pageText = ""
                if (html != null) {
                    val blocks = WebImporter.ldBlocks(html)
                    step("Hämtade ${html.length / 1024} kB, ${blocks.size} datablock")
                    recipes = listOfNotNull(WebImporter.recipeFromLdBlocks(blocks, url))
                    pageText = WebImporter.htmlToText(html)
                }

                // 2. Öppna sidan i en osynlig webbläsare
                if (recipes.isEmpty()) {
                    _busy.value = "Öppnar sidan i webbläsaren…"
                    val page = runCatching { WebViewLoader.load(ctx, url) }
                        .onFailure { step("Webbläsaren misslyckades: ${it.message ?: it.javaClass.simpleName}") }
                        .getOrNull()
                    if (page != null) {
                        step("Webbläsaren: ${page.ldJson.size} datablock, ${page.text.length} tecken text")
                        recipes = listOfNotNull(WebImporter.recipeFromLdBlocks(page.ldJson, url))
                        if (page.text.length > pageText.length) pageText = page.text.take(40_000)
                    } else step("Webbläsaren gav inget svar")
                }

                // 3. Låt Claude läsa sidans text
                if (recipes.isEmpty() && pageText.isNotBlank() && data.value.settings.apiKey.isNotBlank()) {
                    _busy.value = "Claude läser sidan…"
                    recipes = claude().recipesFromText(pageText, url)
                    step("Claude hittade ${recipes.size} recept")
                }

                if (recipes.isEmpty()) {
                    _alert.value = buildString {
                        append("Kunde inte läsa in receptet från\n$url\n\n")
                        if (pageText.isNotBlank() && data.value.settings.apiKey.isBlank())
                            append("Med en API-nyckel kan Claude läsa sidan i stället.\n\n")
                        append("Detaljer (skicka gärna till Claude):\n")
                        append(log.joinToString("\n"))
                    }
                    onDone(null)
                } else {
                    val (added, _) = addRecipes(recipes)
                    if (added == 0) _alert.value = "Receptet \"${recipes.first().title}\" finns redan."
                    else say("Sparade \"${recipes.first().title}\".")
                    onDone(data.value.recipes.lastOrNull { it.title == recipes.first().title }?.id)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                step("Fel: ${e.message ?: e.javaClass.simpleName}")
                _alert.value = "Något gick fel.\n\n" + log.joinToString("\n")
                onDone(null)
            } finally {
                _busy.value = null
            }
        }
    }

    // ---------------- Veckomeny ----------------

    fun setMenu(date: LocalDate, recipeId: String?, servings: Int, note: String = "") = repo.update { d ->
        val key = date.toString()
        if (recipeId == null) d.copy(menu = d.menu - key)
        else d.copy(menu = d.menu + (key to MenuEntry(recipeId, servings, note)))
    }

    fun suggestWeek(weekStart: LocalDate, replaceAll: Boolean) {
        val d = data.value
        val dates = (0..6).map { weekStart.plusDays(it.toLong()) }
            .filter { replaceAll || d.menu[it.toString()]?.recipeId == null }
        if (dates.isEmpty()) return say("Veckan är redan fylld.")
        val servings = d.settings.defaultServings

        if (d.settings.apiKey.isBlank()) {
            // Utan API-nyckel: slumpa ur egna recept
            if (d.recipes.isEmpty()) return say("Lägg till recept eller en API-nyckel för att få förslag.")
            val pool = d.recipes.shuffled().toMutableList()
            dates.forEach { date ->
                if (pool.isEmpty()) pool += d.recipes.shuffled()
                setMenu(date, pool.removeAt(0).id, servings)
            }
            return say("Slumpade fram en meny ur dina recept. Lägg in en API-nyckel för smartare förslag.")
        }

        viewModelScope.launch {
            if (d.stores.isNotEmpty() && offersStale()) {
                runCatching { fetchOffers() }
            }
            _busy.value = "Claude planerar veckan…"
            try {
                val recent = d.menu.filterKeys { it >= weekStart.minusWeeks(3).toString() && it < weekStart.toString() }
                    .values.mapNotNull { it.recipeId }.distinct()
                val sugg = claude().suggestWeek(
                    dates = dates.map { it.toString() },
                    recipes = d.recipes,
                    recentlyUsed = recent,
                    preferences = d.settings.preferences,
                    newIdeas = d.settings.newIdeasPerWeek.coerceAtMost(dates.size),
                    servings = servings,
                    month = weekStart.month.getDisplayName(TextStyle.FULL, Locale("sv")),
                    offers = currentOffers(),
                )
                val newRecipes = sugg.mapNotNull { it.newRecipe }
                if (newRecipes.isNotEmpty()) repo.update { it.copy(recipes = it.recipes + newRecipes) }
                sugg.forEach { s ->
                    val date = runCatching { LocalDate.parse(s.date) }.getOrNull() ?: return@forEach
                    if (date !in dates) return@forEach
                    val id = s.recipeId ?: s.newRecipe?.id ?: return@forEach
                    setMenu(date, id, servings, s.reason)
                }
                say("Veckan är planerad." + if (newRecipes.isNotEmpty()) " ${newRecipes.size} nya recept sparades med taggen \"förslag\"." else "")
            } catch (e: Exception) {
                say(e.message ?: "Något gick fel.")
            } finally {
                _busy.value = null
            }
        }
    }

    // ---------------- Inköpslista ----------------

    fun addRecipeToShopping(recipe: Recipe, servings: Int) = addNeeds(listOf(recipe to servings))

    // Inköpslistan följer en vecka i veckomenyn. Varorna därifrån (auto) byggs om
    // automatiskt vid varje ändring. Egna varor och "Handla" från ett recept ligger kvar.

    fun weekOf(d: AppData): LocalDate =
        d.linkedWeek?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?: LocalDate.now().with(java.time.DayOfWeek.MONDAY)

    private fun syncShopping(d: AppData): AppData {
        val start = weekOf(d)
        val staples = d.settings.pantryStaples
        val needs = (0..6).flatMap { i ->
            val date = start.plusDays(i.toLong()).toString()
            if (date in d.excludedDays) return@flatMap emptyList()
            val e = d.menu[date] ?: return@flatMap emptyList()
            val r = d.recipes.firstOrNull { it.id == e.recipeId } ?: return@flatMap emptyList()
            val factor = e.servings.toDouble() / r.servings.coerceAtLeast(1)
            r.ingredients.filterNot { IngredientText.isStaple(it.name, staples) }
                .map { IngredientText.Need(it.copy(amount = it.amount?.times(factor)), r.title) }
        }
        val old = d.shopping.filter { it.auto }.associateBy { IngredientText.key(it.name, it.unit) }
        val fresh = IngredientText.merge(needs).mapNotNull { item ->
            val k = IngredientText.key(item.name, item.unit)
            if (k in d.hiddenAutoKeys) return@mapNotNull null
            val o = old[k]
            item.copy(auto = true, id = o?.id ?: item.id, checked = o?.checked ?: false)
        }
        val unchanged = fresh.size == old.size && fresh.all { f -> old.values.any { it == f } }
        return if (unchanged) d else d.copy(shopping = d.shopping.filter { !it.auto } + fresh)
    }

    fun linkWeek(weekStart: LocalDate) = repo.update { d ->
        val thisWeek = LocalDate.now().with(java.time.DayOfWeek.MONDAY)
        d.copy(linkedWeek = if (weekStart == thisWeek) null else weekStart.toString(), hiddenAutoKeys = emptySet())
    }

    fun toggleDay(date: LocalDate) = repo.update { d ->
        val k = date.toString()
        d.copy(excludedDays = if (k in d.excludedDays) d.excludedDays - k else d.excludedDays + k)
    }

    fun restoreHidden() = repo.update { it.copy(hiddenAutoKeys = emptySet()) }

    private fun addNeeds(list: List<Pair<Recipe, Int>>) {
        val staples = data.value.settings.pantryStaples
        val needs = list.flatMap { (r, servings) ->
            val factor = servings.toDouble() / r.servings.coerceAtLeast(1)
            r.ingredients.filterNot { IngredientText.isStaple(it.name, staples) }.map {
                IngredientText.Need(it.copy(amount = it.amount?.times(factor)), r.title)
            }
        }
        repo.update { d ->
            // Slå ihop med egna varor som inte är avbockade
            val open = d.shopping.filter { !it.checked && !it.auto }
            val existingNeeds = open.map {
                IngredientText.Need(
                    se.krillster.recepthjalpen.data.Ingredient(it.name, it.amount, it.unit, category = it.category),
                    it.fromRecipes.joinToString(", ")
                )
            }
            val merged = IngredientText.merge(existingNeeds + needs).map { item ->
                item.copy(fromRecipes = item.fromRecipes.flatMap { s -> s.split(", ") }.filter { it.isNotBlank() }.distinct())
            }
            d.copy(shopping = d.shopping.filter { it.checked || it.auto } + merged)
        }
        say("Lade till ingredienserna från ${list.first().first.title} i inköpslistan.")
    }

    fun addShoppingText(text: String) {
        if (text.isBlank()) return
        val ing = IngredientText.parse(text)
        repo.update { it.copy(shopping = it.shopping + ShoppingItem(
            id = UUID.randomUUID().toString(), name = ing.name, amount = ing.amount, unit = ing.unit, category = ing.category
        )) }
    }

    fun toggleShopping(id: String) = repo.update { d ->
        d.copy(shopping = d.shopping.map { if (it.id == id) it.copy(checked = !it.checked) else it })
    }

    private fun hide(d: AppData, items: List<ShoppingItem>): AppData = d.copy(
        hiddenAutoKeys = d.hiddenAutoKeys + items.filter { it.auto }.map { IngredientText.key(it.name, it.unit) },
        shopping = d.shopping.filter { s -> items.none { it.id == s.id } },
    )

    fun deleteShopping(id: String) = repo.update { d -> hide(d, d.shopping.filter { it.id == id }) }
    fun clearChecked() = repo.update { d -> hide(d, d.shopping.filter { it.checked }) }
    fun clearShopping() = repo.update { d -> hide(d, d.shopping) }

    fun shoppingAsText(): String {
        val items = data.value.shopping.filter { !it.checked }
        return se.krillster.recepthjalpen.data.Categories.ALL.mapNotNull { cat ->
            val inCat = items.filter { it.category == cat }
            if (inCat.isEmpty()) null
            else "$cat\n" + inCat.joinToString("\n") { "☐ " + itemLabel(it) }
        }.joinToString("\n\n")
    }

    // ---------------- Butiker & erbjudanden ----------------

    fun addStore(chain: String, name: String, url: String) = repo.update { d ->
        d.copy(stores = d.stores + se.krillster.recepthjalpen.data.Store(UUID.randomUUID().toString(), chain, name.trim(), url))
    }

    fun removeStore(id: String) = repo.update { d ->
        d.copy(stores = d.stores.filter { it.id != id }, offers = d.offers.filter { it.storeId != id })
    }

    /** Erbjudanden gäller oftast måndag–söndag. Hämta om de är från en tidigare vecka. */
    fun offersStale(): Boolean {
        val d = data.value
        if (d.offersFetched == 0L) return true
        val fetched = java.time.Instant.ofEpochMilli(d.offersFetched).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        return fetched.with(java.time.DayOfWeek.MONDAY) != LocalDate.now().with(java.time.DayOfWeek.MONDAY)
    }

    fun currentOffers() = if (offersStale()) emptyList() else data.value.offers

    private suspend fun fetchOffers(): String {
        val d = data.value
        if (d.settings.apiKey.isBlank()) return "För att läsa erbjudanden behövs en Claude API-nyckel."
        val client = ClaudeClient(d.settings.apiKey, OFFERS_MODEL)
        val results = mutableListOf<String>()
        val all = mutableListOf<se.krillster.recepthjalpen.data.Offer>()
        var anyOk = false
        for (store in d.stores) {
            _busy.value = "Hämtar erbjudanden från ${store.name}…"
            val text = WebViewLoader.loadText(ctx, store.url)
            if (text.isNullOrBlank() || text.length < 300) {
                results += "${store.name}: sidan gick inte att läsa"
                all += d.offers.filter { it.storeId == store.id }
                continue
            }
            _busy.value = "Claude läser erbjudandena från ${store.name}…"
            try {
                val offers = client.offersFromText(text, store)
                if (offers.isEmpty()) {
                    results += "${store.name}: hittade inga erbjudanden – kolla att sidan visar butikens erbjudanden"
                    all += d.offers.filter { it.storeId == store.id }
                } else {
                    results += "${store.name}: ${offers.size} erbjudanden"
                    all += offers
                    anyOk = true
                }
            } catch (e: Exception) {
                results += "${store.name}: ${e.message}"
                all += d.offers.filter { it.storeId == store.id }
            }
        }
        repo.update { it.copy(offers = all, offersFetched = if (anyOk) System.currentTimeMillis() else it.offersFetched) }
        return results.joinToString("\n")
    }

    fun refreshOffers() {
        val d = data.value
        if (d.stores.isEmpty()) { _alert.value = "Lägg till dina butiker under Inställningar först."; return }
        if (urlJob?.isActive == true) return
        urlJob = viewModelScope.launch {
            try {
                _alert.value = fetchOffers()
            } finally {
                _busy.value = null
            }
        }
    }

    fun addOfferToShopping(o: se.krillster.recepthjalpen.data.Offer) {
        repo.update { it.copy(shopping = it.shopping + ShoppingItem(
            id = UUID.randomUUID().toString(), name = o.name, category = o.category,
            fromRecipes = listOf("Erbjudande ${o.storeName}: ${o.price}")
        )) }
        say("${o.name} lades i inköpslistan.")
    }

    // ---------------- Inställningar & säkerhetskopia ----------------

    fun updateSettings(transform: (Settings) -> Settings) = repo.update { it.copy(settings = transform(it.settings)) }

    fun exportBackup(uri: Uri) = viewModelScope.launch {
        runCatching {
            withContext(Dispatchers.IO) {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(repo.exportJson().toByteArray()) }
            }
        }.onSuccess { say("Säkerhetskopian är sparad. (Bilderna ingår inte, och API-nyckeln sparas inte.)") }
            .onFailure { say("Kunde inte spara: ${it.message}") }
    }

    fun importBackup(uri: Uri) = viewModelScope.launch {
        runCatching {
            val text = withContext(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(uri)?.use { it.bufferedReader().readText() } ?: ""
            }
            repo.importJson(text)
        }.onSuccess { say("Läste in $it nya recept från säkerhetskopian.") }
            .onFailure { say("Kunde inte läsa filen: ${it.message}") }
    }

    companion object {
        const val OFFERS_MODEL = "claude-haiku-5-5"

        fun itemLabel(i: ShoppingItem): String {
            val a = IngredientText.formatAmount(i.amount)
            return listOf(a, i.unit, i.name).filter { it.isNotBlank() }.joinToString(" ")
        }
    }
}
