package se.krillster.recepthjalpen.data

import kotlinx.serialization.Serializable

@Serializable
data class Ingredient(
    val name: String,
    val amount: Double? = null,
    val unit: String = "",
    val note: String = "",
    val category: String = Categories.OTHER,
)

@Serializable
data class Recipe(
    val id: String,
    val title: String,
    val servings: Int = 4,
    val timeMinutes: Int? = null,
    val ingredients: List<Ingredient> = emptyList(),
    val steps: List<String> = emptyList(),
    val tags: List<String> = emptyList(),
    val notes: String = "",
    val source: String = "",
    val imagePath: String? = null,
    val favorite: Boolean = false,
    val created: Long = System.currentTimeMillis(),
)

@Serializable
data class MenuEntry(
    val recipeId: String? = null,
    val servings: Int = 4,
    val note: String = "",
)

@Serializable
data class ShoppingItem(
    val id: String,
    val name: String,
    val amount: Double? = null,
    val unit: String = "",
    val category: String = Categories.OTHER,
    val checked: Boolean = false,
    val fromRecipes: List<String> = emptyList(),
)

@Serializable
data class Settings(
    val apiKey: String = "",
    val model: String = "claude-sonnet-5-5",
    val defaultServings: Int = 4,
    val preferences: String = "",
    val newIdeasPerWeek: Int = 2,
    val pantryStaples: String = "salt, peppar, vatten, olja, smör",
    val folderUri: String? = null,
)

@Serializable
data class AppData(
    val recipes: List<Recipe> = emptyList(),
    /** Nyckel: datum i formatet yyyy-MM-dd */
    val menu: Map<String, MenuEntry> = emptyMap(),
    val shopping: List<ShoppingItem> = emptyList(),
    val settings: Settings = Settings(),
    /** Bilder (dokument-URI) som redan har tolkats, så de inte läses in igen. */
    val importedUris: Set<String> = emptySet(),
)

object Categories {
    const val PRODUCE = "Frukt & grönt"
    const val MEAT = "Kött, fågel & fisk"
    const val DAIRY = "Mejeri & ägg"
    const val BREAD = "Bröd"
    const val PANTRY = "Skafferi"
    const val SPICES = "Kryddor & såser"
    const val FROZEN = "Fryst"
    const val OTHER = "Övrigt"
    val ALL = listOf(PRODUCE, MEAT, DAIRY, BREAD, PANTRY, SPICES, FROZEN, OTHER)

    fun normalize(category: String?, name: String): String =
        ALL.firstOrNull { it.equals(category?.trim(), ignoreCase = true) }
            ?: IngredientText.guessCategory(name)
}
