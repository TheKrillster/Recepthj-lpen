package se.krillster.recepthjalpen.ui

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import se.krillster.recepthjalpen.data.Categories

@Composable
fun ShoppingScreen(vm: AppViewModel, modifier: Modifier) {
    val data by vm.data.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var newItem by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val items = data.shopping
    val open = items.filter { !it.checked }
    val checked = items.filter { it.checked }

    fun add() { vm.addShoppingText(newItem); newItem = "" }

    LazyColumn(modifier, contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Row(Modifier.padding(start = 16.dp, top = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Inköpslista", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                    Text("${open.size} kvar" + if (checked.isNotEmpty()) " · ${checked.size} i korgen" else "",
                        style = MaterialTheme.typography.bodySmall)
                }
                IconButton(enabled = open.isNotEmpty(), onClick = {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, "Inköpslista\n\n" + vm.shoppingAsText())
                    context.startActivity(Intent.createChooser(send, "Dela inköpslistan"))
                }) { Icon(Icons.Filled.Share, "Dela") }
                IconButton(enabled = items.isNotEmpty(), onClick = { confirmClear = true }) { Icon(Icons.Filled.Delete, "Töm") }
            }
            OutlinedTextField(
                value = newItem, onValueChange = { newItem = it },
                placeholder = { Text("Lägg till vara, t.ex. 1 l mjölk") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { add() }),
                trailingIcon = { IconButton(onClick = { add() }) { Icon(Icons.Filled.Add, "Lägg till") } },
                modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp)
            )
            if (items.isEmpty()) Text(
                "Listan är tom. Lägg till varor här, eller tryck \"Handla allt\" i veckomenyn eller \"Handla\" på ett recept.\n\nBasvaror du alltid har hemma (salt, peppar m.m.) hoppas över – ändra dem under Inställningar.",
                modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Categories.ALL.forEach { cat ->
            val inCat = open.filter { it.category == cat }.sortedBy { it.name.lowercase() }
            if (inCat.isNotEmpty()) {
                item(key = "h-$cat") {
                    Text(cat, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 0.dp))
                }
                items(inCat, key = { it.id }) { ShoppingRow(vm, it) }
            }
        }
        val strays = open.filter { it.category !in Categories.ALL }
        items(strays, key = { it.id }) { ShoppingRow(vm, it) }
        if (checked.isNotEmpty()) {
            item(key = "checked-header") {
                Row(Modifier.padding(start = 16.dp, top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("I korgen", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.clearChecked() }) { Text("Rensa") }
                }
            }
            items(checked, key = { it.id }) { ShoppingRow(vm, it) }
        }
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Tömma listan?") },
        text = { Text("Alla varor tas bort från inköpslistan.") },
        confirmButton = { TextButton(onClick = { vm.clearShopping(); confirmClear = false }) { Text("Töm") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Avbryt") } }
    )
}

@Composable
private fun ShoppingRow(vm: AppViewModel, item: se.krillster.recepthjalpen.data.ShoppingItem) {
    Row(
        Modifier.fillMaxWidth().clickable { vm.toggleShopping(item.id) }.padding(start = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = item.checked, onCheckedChange = { vm.toggleShopping(item.id) })
        Column(Modifier.weight(1f)) {
            Text(
                AppViewModel.itemLabel(item),
                textDecoration = if (item.checked) TextDecoration.LineThrough else null,
                color = if (item.checked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
            if (item.fromRecipes.isNotEmpty() && !item.checked)
                Text(item.fromRecipes.joinToString(", "), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
        IconButton(onClick = { vm.deleteShopping(item.id) }) {
            Icon(Icons.Filled.Close, "Ta bort", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
